# -*- coding: utf-8 -*- 
"""
/*
 * Boblight menu, for enigma2
 * Copyright (C) Martijn Vos (speedy1985) 2012-2013
 *
 * boblight is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * boblight is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"""
from __init__ import _
import sys, time, socket, os, commands, threading
from time import sleep
from Screens import Standby
from Screens.Standby import TryQuitMainloop
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Console import Console
from Components.ConfigList import ConfigListScreen
from Components.config import config, configfile, getConfigListEntry, ConfigFloat, ConfigSubsection, ConfigEnableDisable, ConfigSelection, ConfigSlider, ConfigDirectory, ConfigOnOff, ConfigNothing, ConfigInteger, ConfigYesNo
from enigma import ePicLoad, eConsoleAppContainer, getDesktop
from Tools import Notifications

SOCKET_NAME = "/tmp/boblight-gui.socket"

boblightconf_notfound   = "boblight.conf not found in /etc !!!"

def tohex(r,g,b):
    hexchars = "0123456789ABCDEF"
    return hexchars[r / 16] + hexchars[r % 16] + hexchars[g / 16] + hexchars[g % 16] + hexchars[b / 16] + hexchars[b % 16]
    
class Boblight():
    
    def __init__ (self):
	self.Console 		= Console()
        self.status             = "...."
        self.chase_active       = False
        self.enigma2_active     = False
        self.daemon_active      = False

        self.hostip             = -1
        self.hostport           = None
        
        self.s                  = None
        self.error              = None
        self.clienthost         = None
        self.clientport         = 30000
        self.conn_status        = None
        self.live_status        = None
        self.isStandby          = False
                        
    ##################################################################################################3

    def Lights_on(self,session):
	#Network Mode, Connect to other boblightd
	if config.plugins.Boblight.network_onoff.value is True:
	    if self.checkDaemon() or config.plugins.Boblight.network_onoff.value is False: 
		self.Control("start")                     
		if config.plugins.Boblight.message_onoff.getValue() is True:     
		    startMsg = _("Enable lights... [%s:%s]") %(self.hostip,self.hostport)
		    session.open(MessageBox, _(startMsg), MessageBox.TYPE_INFO, timeout=3)
	    else:
		session.open(MessageBox, _(boblightconf_notfound), MessageBox.TYPE_WARNING, timeout=4)     
	else:
	    #Local Mode, Connect to local boblightd
	    if os.path.isfile("/etc/boblight.conf") is True:
		self.Control("start")                     
		if config.plugins.Boblight.message_onoff.getValue() is True:     
		    startMsg = _("Enable lights... [%s:%s]") %(self.hostip,self.hostport)
		    session.open(MessageBox, _(startMsg), MessageBox.TYPE_INFO, timeout=3)
	    else:
		startMsg = _("Client can't connect with daemon at %s:%s\nIs daemon started on host ?") %(self.hostip,self.hostport)
		session.open(MessageBox, _(startMsg), MessageBox.TYPE_WARNING)
        self.getStatus()
        
    def Lights_off(self,session):
        self.Control("stop")
        if config.plugins.Boblight.message_onoff.getValue() is True: 
            startMsg = _("Disable lights... [%s:%s]") %(self.hostip,self.hostport)  
            session.open(MessageBox, _(startMsg), MessageBox.TYPE_INFO, timeout=3)
        self.getStatus()
    
    def Restart(self,session):    
        #Network Mode, Connect to other boblightd
	if config.plugins.Boblight.network_onoff.value is True:
	    if self.checkDaemon() or config.plugins.Boblight.network_onoff.value is False: 
		self.Control("start")                     
		if config.plugins.Boblight.message_onoff.getValue() is True:     
		    startMsg = _("Restart client... [%s:%s]") %(self.hostip,self.hostport)
		    session.open(MessageBox, _(startMsg), MessageBox.TYPE_INFO, timeout=3)
	    else:
		session.open(MessageBox, _(boblightconf_notfound), MessageBox.TYPE_WARNING, timeout=4)     
	else:
	    #Local Mode, Connect to local boblightd
	    if os.path.isfile("/etc/boblight.conf") is True:
		self.Control("start")                     
		if config.plugins.Boblight.message_onoff.getValue() is True:     
		    startMsg = _("Restart client... [%s:%s]") %(self.hostip,self.hostport)
		    session.open(MessageBox, _(startMsg), MessageBox.TYPE_INFO, timeout=3)
	    else:
		startMsg = _("Client can't connect with daemon at %s:%s\nIs daemon started on host ?") %(self.hostip,self.hostport)
		session.open(MessageBox, _(startMsg), MessageBox.TYPE_WARNING)
        self.getStatus()

    #####################################################################################################
    
    def checkDaemon(self):
        if config.plugins.Boblight.network_onoff.value is True:
	    print "[Boblight] Check daemon on address: %s:%s" %(self.hostip, str(self.hostport))
	    sock = None
	    try:
		sock = socket.socket()
		sock.settimeout(5)
		sock.connect((self.hostip, self.hostport))
		return True
	    except Exception, e:
		return False
	    finally:
		if sock != None:
		    sock.close()
	
    def validIP(self,address):
	parts = address.split(".")
	if len(parts) != 4:
	    return False
	for item in parts:
	    if not 0 <= int(item) <= 255:
		return False
	return True

    def checkNetwork(self):
        #handle network connection
        if not config.plugins.Boblight.network_onoff.value:
            self.hostip   = "127.0.0.1"
            self.hostport = 19333 
        else:
	    self.hostip   = "%s" %(str(config.plugins.Boblight.address.getText()))
	    print "[Boblight] Daemon ip addres = " + self.hostip
	    if self.validIP(str(config.plugins.Boblight.address.getText())):		
		    self.hostip   = "%s" %(str(config.plugins.Boblight.address.getText()))
		    self.hostport = config.plugins.Boblight.port.value
	    else:
		    self.hostip   = "127.0.0.1"
		    config.plugins.Boblight.address.value = [127,0,0,1]
		    config.plugins.Boblight.address.save()
		    configfile.save()
		
    def getStatus(self):
        
        mode = None
        self.checkNetwork() #check the networkip               
        self.checkClient() #check client
                    
        if config.plugins.Boblight.mode.value == str(2):
            mode = "dynamic"
        elif config.plugins.Boblight.mode.value == str(1):
            mode = "moodlamp(static)"

        if self.enigma2_active: 
            ret = 1
        else:
            ret = 0

        return ret
		
    def Control(self,s):
        print "[Boblight] Control()"
        container = eConsoleAppContainer()
        ret = self.getStatus()
        if s == "start" and ret == 0:
            container.execute('/etc/init.d/boblight-control start')
        elif s == "stop" and ret == 1:
            container.execute('/etc/init.d/boblight-control stop')
        elif s == "restart":
            container.execute('/etc/init.d/boblight-control restart')
        elif s == "test":
            container.execute('/etc/init.d/boblight-test start')
        elif s == "kill":
            container.execute('/etc/init.d/boblight-control forcekill')
        
    def checkMode(self):
	    print "[Boblight] checkMode()"
	    return str(config.plugins.Boblight.mode.value)
    
    def checkClient(self):        
        ret = self.sendCommand("hello","0")
        if ret == 0:
            self.enigma2_active = False
        elif ret == 1:
            self.enigma2_active = True
	    
        return ret
                    
    def sendCommand(self, command, value):
        
        ret = 0
        
        #make value lower
        if value == "True":
            value = "true"
        elif value == "False":
            value = "false"
        
        if command is not None:            
            try:
                 #create connection
                
                self.s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)                
                self.s.connect(SOCKET_NAME)
                
                #print "[Boblight:Write] Set option %s %s" %(command,value)
  
                self.s.send("%s %s" % (command, value))
                self.s.close()
                self.error = ""
                ret = 1
            except socket.error, msg:
                if "No such file or directory" not in str(msg):
                    print "[Boblight:Write] %s %s Error: %s" %(command,value,str(msg))
                self.s.close()
                self.s = None
                self.error = "\nWriteError: %s" %(str(msg))
                ret = 0
        return ret
    
    def closeSocket(self):
        if self.s != None:
            self.s.close()
        
    def changeValue(self, currentoption):
             
        value = str(currentoption.getValue())
        text  = str(currentoption.getText())
        
        if currentoption == config.plugins.Boblight.saturation:
            ret = self.sendCommand("saturation",str(value))
        elif currentoption == config.plugins.Boblight.saturationmin:
            ret = self.sendCommand("saturationmin",str(value))
        elif currentoption == config.plugins.Boblight.saturationmax:
            ret = self.sendCommand("saturationmax",str(value))
        elif currentoption == config.plugins.Boblight.value:
            ret = self.sendCommand("value",str(value))
        elif currentoption == config.plugins.Boblight.valuemin:
            ret = self.sendCommand("valuemin",str(value))
        elif currentoption == config.plugins.Boblight.valuemax:
            ret = self.sendCommand("valuemax",str(value))
        elif currentoption == config.plugins.Boblight.speed:
            ret = self.sendCommand("speed",str(value))
	elif currentoption == config.plugins.Boblight.m_delay:
            ret = self.sendCommand("delay",str(value))
        elif currentoption == config.plugins.Boblight.autospeed:
            ret = self.sendCommand("autospeed",str(value))
        elif currentoption == config.plugins.Boblight.gamma:
            ret = self.sendCommand("gamma",str(value))
        elif currentoption == config.plugins.Boblight.m_3dmode:
            ret = self.sendCommand("3dmode",str(value))
        elif currentoption == config.plugins.Boblight.interpolation:
            ret = self.sendCommand("interpolation",str(value))
        elif currentoption == config.plugins.Boblight.blackbar:
            ret = self.sendCommand("blackbar",str(value))
        elif currentoption == config.plugins.Boblight.threshold:
            ret = self.sendCommand("threshold",str(value))
        elif currentoption == config.plugins.Boblight.cluster:
            ret = self.sendCommand("cluster",str(value))
        elif currentoption == config.plugins.Boblight.mode:
            if text == _("Moodlamp"):
                if config.plugins.Boblight.moodlamp_mode.getValue() == str(1):
                    
                    ret = self.sendCommand("threshold",str(0))
		    
		    if config.plugins.Boblight.color.getValue() == "rgb":
			color = tohex(config.plugins.Boblight.moodlamp_static_color_r.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_b.getValue())
		    elif config.plugins.Boblight.color.getValue() == "bgr":
			color = tohex(config.plugins.Boblight.moodlamp_static_color_b.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_r.getValue())
		    		
                    ret = self.sendCommand("static_color",str(color))  #set color
                    ret = self.sendCommand("mode","static")                            
                elif config.plugins.Boblight.moodlamp_mode.getValue() == str(4):                
                    ret = self.sendCommand("faderbrightness",str(config.plugins.Boblight.moodlamp_fader_brightness.getValue()))
                    ret = self.sendCommand("threshold",str(0))                
                    ret = self.sendCommand("mode","colorfader")            
            if text == _("Dynamic"):
                ret = self.sendCommand("threshold",str(value))
                ret = self.sendCommand("mode","dynamic")
                 
        elif currentoption == config.plugins.Boblight.moodlamp_mode:  #Change mode
            if text == _("Static color"):
                if config.plugins.Boblight.mode.getValue() != str(2):
                    if config.plugins.Boblight.color.getValue() == "rgb":
			color = tohex(config.plugins.Boblight.moodlamp_static_color_r.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_b.getValue())
		    elif config.plugins.Boblight.color.getValue() == "bgr":
			color = tohex(config.plugins.Boblight.moodlamp_static_color_b.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_r.getValue())
		    
                    ret = self.sendCommand("threshold",str(0))
                    ret = self.sendCommand("static_color",str(color))  #set color
		    
                    ret = self.sendCommand("mode","static")                
            if text == _("Color fader"):
                if config.plugins.Boblight.mode.getValue() != str(2):
                    ret = self.sendCommand("faderbrightness",str(config.plugins.Boblight.moodlamp_fader_brightness.getValue()))
                    ret = self.sendCommand("threshold",str(0))                
                    ret = self.sendCommand("mode","colorfader")
            
        elif currentoption == config.plugins.Boblight.presets: #send all setting
            th = threading.Thread(target=self.sendAll(), args=[])
            th.start()             
        elif currentoption == config.plugins.Boblight.interval:
            ret = self.sendCommand("interval",str(value))  #set the interval        
        elif currentoption == config.plugins.Boblight.moodlamp_static_color_r or config.plugins.Boblight.moodlamp_static_color_g or config.plugins.Boblight.moodlamp_static_color_b or config.plugins.Boblight.moodlamp_fader_brightness or currentoption == config.plugins.Boblight.adjustr or config.plugins.Boblight.adjustg or config.plugins.Boblight.adjustb or config.plugins.Boblight.color or config.plugins.Boblight.use_live_adjust:
	    if config.plugins.Boblight.color.getValue() == "rgb":
		if config.plugins.Boblight.use_live_adjust.value == True:
		    ret = self.sendCommand("adjust",str(str(config.plugins.Boblight.adjustr.value) + " " + str(config.plugins.Boblight.adjustg.value) + " " + str(config.plugins.Boblight.adjustb.value)))
		else:
		    ret = self.sendCommand("adjust",str(0) + " " + str(0) + " " + str(0))
		color = tohex(config.plugins.Boblight.moodlamp_static_color_r.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_b.getValue())
	    elif config.plugins.Boblight.color.getValue() == "bgr":
		if config.plugins.Boblight.use_live_adjust.value == True:
		    ret = self.sendCommand("adjust",str(str(config.plugins.Boblight.adjustb.value) + " " + str(config.plugins.Boblight.adjustg.value) + " " + str(config.plugins.Boblight.adjustr.value)))
		else:
		    ret = self.sendCommand("adjust",str(0) + " " + str(0) + " " + str(0))
		color = tohex(config.plugins.Boblight.moodlamp_static_color_b.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_r.getValue())
	    ret = self.sendCommand("static_color",str(color))  #set color  
            
	    
	    if config.plugins.Boblight.moodlamp_mode.getValue() == str(4):
                ret = self.sendCommand("faderbrightness",str(config.plugins.Boblight.moodlamp_fader_brightness.getValue()))                
        else:
            return
                
    def sendAll(self):   
	if config.plugins.Boblight.color.getValue() == "rgb" and config.plugins.Boblight.use_live_adjust.value == True:
	    self.sendCommand("adjust",str(str(config.plugins.Boblight.adjustr.value) + " " + str(config.plugins.Boblight.adjustg.value) + " " + str(config.plugins.Boblight.adjustb.value)))
	elif config.plugins.Boblight.color.getValue() == "bgr" and config.plugins.Boblight.use_live_adjust.value == True:
	    self.sendCommand("adjust",str(str(config.plugins.Boblight.adjustb.value) + " " + str(config.plugins.Boblight.adjustg.value) + " " + str(config.plugins.Boblight.adjustr.value)))
	else:
	    self.sendCommand("adjust",str(0) + " " + str(0) + " " + str(0))
	    
        self.sendCommand("saturation",str(config.plugins.Boblight.saturation.value))
        self.sendCommand("saturationmin",str(config.plugins.Boblight.saturationmin.value))
        self.sendCommand("saturationmax",str(config.plugins.Boblight.saturationmax.value))
        self.sendCommand("value",str(config.plugins.Boblight.value.value))
        self.sendCommand("valuemin",str(config.plugins.Boblight.valuemin.value))
        self.sendCommand("valuemax",str(config.plugins.Boblight.valuemax.value))
        self.sendCommand("speed",str(config.plugins.Boblight.speed.value))
        self.sendCommand("autospeed",str(config.plugins.Boblight.autospeed.value))
        self.sendCommand("gamma",str(config.plugins.Boblight.gamma.value))
        self.sendCommand("interpolation",str(config.plugins.Boblight.interpolation.value))
        self.sendCommand("threshold",str(config.plugins.Boblight.threshold.value))         
        self.sendCommand("interval",str(config.plugins.Boblight.interval.value))
        self.sendCommand("blackbar",str(config.plugins.Boblight.blackbar.value))
        self.sendCommand("3dmode",str(config.plugins.Boblight.m_3dmode.value))
        self.sendCommand("cluster",str(config.plugins.Boblight.cluster.value))
        self.sendCommand("delay",str(config.plugins.Boblight.m_delay.value))
	
        if config.plugins.Boblight.mode.getText() != _("Dynamic"):
            if config.plugins.Boblight.mode.getText() == _("Moodlamp") and config.plugins.Boblight.moodlamp_mode.getValue() == str(1):                          
                self.sendCommand("mode","static")
                
		if config.plugins.Boblight.color.getValue() == "rgb":
		    color = tohex(config.plugins.Boblight.moodlamp_static_color_r.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_b.getValue())
		elif config.plugins.Boblight.color.getValue() == "bgr":
		    color = tohex(config.plugins.Boblight.moodlamp_static_color_b.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_r.getValue())
		
                self.sendCommand("static_color",str(color))  #set color
                self.sendCommand("threshold",str(0))
                
            if config.plugins.Boblight.mode.getText() == _("Moodlamp") and config.plugins.Boblight.moodlamp_mode.getValue() == str(4):                             
                self.sendCommand("mode","colorfader")
                self.sendCommand("faderbrightness",str(config.plugins.Boblight.moodlamp_fader_brightness.getValue()))
                self.sendCommand("threshold",str(0))
            
        if config.plugins.Boblight.mode.getText() == _("Dynamic"):
            self.sendCommand("mode","dynamic")
            self.sendCommand("threshold",str(config.plugins.Boblight.threshold.value))                
    
    def enterStandby(self, configElement):
        if not self.isStandby and self.checkClient() == 1:
            Standby.inStandby.onClose.append(self.leaveStandby)
	    self.isStandby = True
            self.container = eConsoleAppContainer()
            self.container.execute('/etc/init.d/boblight-control sleep')
                          
    def leaveStandby(self):
        if self.isStandby is True:
	    self.isStandby = False
	    self.container = eConsoleAppContainer()
            self.container.execute('/etc/init.d/boblight-control wakeup')
            
