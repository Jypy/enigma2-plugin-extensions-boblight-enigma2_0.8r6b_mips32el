# -*- coding: utf-8 -*- 
"""
/*
 * Boblight menu, for enigma2
 * Copyright (C) Martijn Vos (speedy1985) 2012-2013
 *
 * boblight is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * boblight is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"""
from __init__ import _
import sys, time, socket, os, commands, threading
from time import sleep
from Screens.MessageBox import MessageBox
from Screens import Standby
from Components.ConfigList import ConfigListScreen
from Components.config import config, configfile, getConfigListEntry, ConfigFloat, ConfigSubsection, ConfigEnableDisable, ConfigSelection, ConfigSlider, ConfigDirectory, ConfigOnOff, ConfigNothing, ConfigInteger, ConfigYesNo
from enigma import eConsoleAppContainer
from boblight import *


class BobSocket(threading.Thread):
    
    def __init__(self):
        threading.Thread.__init__(self)
        self.session = None
        self.m_bob = Boblight()
        self.dialog  = None
        self.s = None        
        self.active  = False        
        self.socket_running = False        
        self.thread_running = True     
        self.host = ""
        self.usesocket   = config.plugins.Boblight.android.value
        self.port = config.plugins.Boblight.android_port.value
        self.backlog = 5
        self.size = 1024
        self.setDaemon(True)
        
    def run(self):
        if self.socket_running == False:
            print "[Boblight] Socket: Open socketconnection for BoblightControl @ port: %s" %(str(config.plugins.Boblight.android_port.value))
                       
            while(self.thread_running):
                if config.plugins.Boblight.android.value == False:
                    time.sleep(1)                    
                else:                    
                    try:                        
                        if str(config.plugins.Boblight.android_port.value) != str(self.port):
                            self.port = config.plugins.Boblight.android_port.value
                            print "[Boblight] Socket: Port changed port for boblightControl to: %s" %(str(self.port))
                        elif config.plugins.Boblight.android.value == False:
                            print ("fout is false")                                                                
                            break
                            
                        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
                        self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                        self.s.settimeout(20) # after 20sec give timeout
                        self.s.bind((self.host,self.port)) 
                        self.s.listen(self.backlog)
                    
                        try:
                                                                           
                            #print "[Boblight:Remotesocket] Socket: Idle"
                            client, address = self.s.accept()                
                            
                            received = client.recv(self.size)   # here wait for data
                                                                        
                            if received:
                                print "[Boblight:Remotesocket] Socket received: %s" %(str(received))
                                
                                data = received.split("|")
                                
                                print "[Boblight:Remotesocket] Socket command: %s | value: %s" %(str(data[0]),str(data[1]))
                                
                                command = str(data[0])
                                value = str(data[1])                                
                                
                                try:
                                    if command == str("bob"):
                                        print "command is bob!"
                                        if value.strip() == str("on"):
                                            self.m_bob.Control("start")
                                            client.send("1")
                                        elif value.strip() == str("off"):
                                            self.m_bob.Control("stop")
                                            client.send("1")
                                        elif value.strip() == str("test"):
                                            self.m_bob.Control("test")
                                            client.send("1")
                                        elif value.strip() == str("getRunningState"):
                                            client.send("Ok|" + str(self.m_bob.checkClient()))
                                        elif value.strip() == str("getMode"):
                                            ret = self.m_bob.checkMode()
                                            client.send("Ok|" + ret)                                            
                                    else:
                                        if command == str("mode"):
                                            if value == str("static"):
                                                config.plugins.Boblight.mode.setValue(str(1))
                                            if value == str("dynamic"):
                                                config.plugins.Boblight.mode.setValue(str(2))
                                            config.plugins.Boblight.mode.save()
                                            
                                        self.m_bob.sendCommand(data[0],data[1]) # send data to client
                                        client.send("Ok|1")
                                except Exception, msg:
                                    print "[Boblight:Remotesocket] Socket error: %s\ncan't send option, command or value are empty or format is wrong." %(str(msg))
                                    client.send("Error|" + str(msg))
                            client.close()
                            
                        except Exception, msg:
                            if str(msg) != "timed out":
                                print "[Boblight:Remotesocket] ExceptionError: %s" %(str(msg))
                        finally:
                            self.s.close()                    
                                            
                    except socket.error, msg:
                        print "[Boblight:Remotesocket] socketError: %s" %(str(msg))
                    finally:
                        self.s = None                        
            print "[Boblight] Socket: exit..."
    
    def gotSession(self, session):
        print("got session")
        self.session = session
        
