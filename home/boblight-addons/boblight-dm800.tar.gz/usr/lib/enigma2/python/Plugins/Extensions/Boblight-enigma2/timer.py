# -*- coding: utf-8 -*- 
"""
/*
 * Boblight menu, for enigma2
 * Copyright (C) Martijn Vos (speedy1985) 2012-2013
 *
 * boblight is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * boblight is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"""
from __init__ import _
import sys, time, socket, os, commands, threading
from time import sleep
from Screens.MessageBox import MessageBox
from Screens import Standby
from Components.ConfigList import ConfigListScreen
from Components.config import *
from enigma import eConsoleAppContainer
  
class BobTimer(threading.Thread):
    
    def __init__(self):
        threading.Thread.__init__(self)
        self.session = None 
        self.dialog  = None
        self.active  = False
        self.timer   = config.plugins.Boblight.timer_onoff.value
        self.timer_running = False
        self.start_hour = None
        self.start_min  = None
        self.end_hour   = None
        self.end_min    = None
        self.thread_timer = None
        self.thread_running = True
        self.isStandby = False
        self.setDaemon(True)            
            
    def run(self):
        config.misc.standbyCounter.addNotifier(self.enterStandby, initial_call = False)
        
        if self.timer_running == False:
            print "[Boblight] Timer thread started.."
            
            while(self.thread_running):
                #check if timer is true
                self.timer = config.plugins.Boblight.timer_onoff.value
                if self.timer:
                    print("[Boblight] Timer start\n")

                    while self.timer != False:
                        
                        #time correction
                        self.start_hour = str(config.plugins.Boblight.time_start.value[0])
                        if len(self.start_hour) == 1:
                            self.start_hour = "0"+self.start_hour
                        self.end_hour = str(config.plugins.Boblight.time_end.value[0])
                        if len(self.end_hour) == 1:
                            self.end_hour = "0"+self.end_hour
                        self.start_min = str(config.plugins.Boblight.time_start.value[1])
                        if len(self.start_min) == 1:
                            self.start_min = "0"+self.start_min
                        self.end_min = str(config.plugins.Boblight.time_end.value[1])
                        if len(self.end_min) == 1:
                            self.end_min = "0"+self.end_min
                                  
                        self.start_time = self.start_hour+":"+self.start_min+":00"
                        self.stop_time  = self.end_hour+":"+self.end_min+":00" 
                        
                        self.timer_running = True
                        
                        if self.isStandby == False:
                            if self.start_time == time.strftime("%H:%M:%S"):
                                container = eConsoleAppContainer()
                                container.execute('/etc/init.d/boblight-control start')
                            if self.stop_time == time.strftime("%H:%M:%S"):
                                container = eConsoleAppContainer()
                                container.execute('/etc/init.d/boblight-control stop')
                                
                        #update timer true or false
                        self.timer = config.plugins.Boblight.timer_onoff.value
                        time.sleep(1)
                        container = None
                    print("[Boblight] Timer stop\n")

                    self.timer_running = False
                #check every 8 seconds
                time.sleep(8)
            print "[Boblight] Timer thread killed.."

    def gotSession(self, session):
        print("got session")
        self.session = session
        
    def enterStandby(self,configElement):
        Standby.inStandby.onClose.append(self.endStandby)
        if config.plugins.Boblight.timer_standby_onoff.value == False:
            self.isStandby = True
      
    def endStandby(self):
        if config.plugins.Boblight.timer_standby_onoff.value == False:
            self.isStandby = False
        
