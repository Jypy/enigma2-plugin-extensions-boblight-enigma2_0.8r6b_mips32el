# -*- coding: utf-8 -*- 
"""
/*
 * Boblight menu, for enigma2
 * Copyright (C) Martijn Vos (speedy1985) 2012-2013
 *
 * boblight is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * boblight is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"""

from __init__ import _
from threading import Thread, Timer
import sys, time, os, signal, socket
from fcntl import ioctl
from time import localtime, mktime

from Components.Sources.CanvasSource import CanvasSource
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import *
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.AVSwitch import AVSwitch
from Components.Sources.ServiceEvent import ServiceEvent
from Components.Button import Button
from Components.FileList import FileList
from Components.Pixmap import Pixmap

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Screens.ServiceInfo import ServiceInfoList, ServiceInfoListEntry
from Screens import Standby

from Tools import Notifications
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import ePicLoad, eConsoleAppContainer, getDesktop, eServiceReference,eTimer, eWidget, eRect, loadPic, iServiceInformation

from app_socket import * # SocketClass to listen/receive values from AndroidApp
from timer import *		 # Class for on/off lights at given time

import urllib2
# Unfortunaly not everyone has twisted installed ...
try:
	from twisted.web.microdom import parseString
except Exception, e:
	print("import twisted.web.microdom failed")

now = [x for x in localtime()]
now[3] = 20
now[4] = 00
def_start = mktime(now)
now[3] = 23
now[4] = 00
def_end = mktime(now)

###################################################################################################################

# the currentVersion should be renewed every major update
currentVersion          = "0.8r6"
defaultPluginFolderPath = resolveFilename(SCOPE_PLUGINS, "Extensions/Boblight-enigma2/")
defaultURL              = "http://www.boblightenigma2.net/updates/"
defaultUpdateXML        = "update.xml"

###################################################################################################################

config.plugins.Boblight = ConfigSubsection()

config.plugins.Boblight.sampleBackground	     = ConfigYesNo(default = False)
config.plugins.Boblight.sampleBackground_mvi         = ConfigSelection(default = "rgb_test", choices = [
("rgb_test", _("RGB Test")),("bars_test", _("Bars Test")),("white", _("Solid: White")),
("aquamarine", _("Solid: Aquamarine")),("blue", _("Solid: Blue")),
("royalblue", _("Solid: Royalblue")),("red", _("Solid: Red")),
("green", _("Solid: Green")),("gray", _("Solid: Gray")),
("lightgray", _("Solid: Lightgray")),("magenta", _("Solid: Magenta")),
("yellow", _("Solid: Yellow")),("yellowdark", _("Solid: Dark yellow")),
("circles", _("Circles")),("rose", _("Rose"))])

config.plugins.Boblight.checkforupdate               = ConfigYesNo(default = True)
config.plugins.Boblight.version                      = ConfigText(default = currentVersion)
config.plugins.Boblight.arch                         = ConfigText(default = "")
	
config.plugins.Boblight.pluginfolderpath             = ConfigText(default = defaultPluginFolderPath)
config.plugins.Boblight.url                          = ConfigText(default = defaultURL)
config.plugins.Boblight.updatexml                    = ConfigText(default = defaultUpdateXML)

config.plugins.Boblight.debug                        = ConfigOnOff(default=False)
config.plugins.Boblight.update                       = ConfigOnOff(default=False)
config.plugins.Boblight.daemon                       = ConfigOnOff(default=False)
config.plugins.Boblight.mode                         = ConfigSelection(default = "2", choices = [
("2", _("Dynamic")), 
("1", _("Moodlamp"))])

config.plugins.Boblight.standbymode                  = ConfigSelection(default = "0", choices = [
("0", _("Lights off")),
("1", _("Moodlamp"))])

config.plugins.Boblight.moodlamp_static_slide        = ConfigSelection(default = "0", choices = [
("0", _("Slider")),
("1", _("Integers"))])

config.plugins.Boblight.moodlamp_fader_brightness    = ConfigSlider(default=100, increment=1, limits=(1,255))
config.plugins.Boblight.moodlamp_static_color_r      = ConfigSlider(default=255, increment=1, limits=(0,255))
config.plugins.Boblight.moodlamp_static_color_g      = ConfigSlider(default=025, increment=1, limits=(0,255))
config.plugins.Boblight.moodlamp_static_color_b      = ConfigSlider(default=002, increment=1, limits=(0,255))

config.plugins.Boblight.moodlamp_static_color_r_int  = ConfigInteger(default = 255, limits=(0, 255))
config.plugins.Boblight.moodlamp_static_color_g_int  = ConfigInteger(default = 025, limits=(0, 255))
config.plugins.Boblight.moodlamp_static_color_b_int  = ConfigInteger(default = 002, limits=(0, 255))

config.plugins.Boblight.address                    = ConfigIP(default=[127,0,0,1])
config.plugins.Boblight.android                    = ConfigOnOff(default=False)
config.plugins.Boblight.android_port               = ConfigInteger(default = 50000, limits=(1, 65535))

config.plugins.Boblight.port                       = ConfigInteger(default = 19333, limits=(1, 65535))
config.plugins.Boblight.network_onoff              = ConfigOnOff(default=False)

config.plugins.Boblight.moodlamp_static            = ConfigOnOff(default=False)
config.plugins.Boblight.moodlamp_mode              = ConfigSelection(default = "1", choices = [
("1", _("Static color")),
("4", _("Color fader"))])

config.plugins.Boblight.use_live_adjust           = ConfigYesNo(default = False)

config.plugins.Boblight.adjustr = ConfigSlider(default=255, increment=1, limits=(0,255))
config.plugins.Boblight.adjustg = ConfigSlider(default=255, increment=1, limits=(0,255))
config.plugins.Boblight.adjustb = ConfigSlider(default=255, increment=1, limits=(0,255))

config.plugins.Boblight.threshold                 = ConfigSlider(default=0, increment=5, limits=(0,255))  
config.plugins.Boblight.pixels                    = ConfigSelection(default = "16", choices = [("16", "16"),("32", "32"), ("64", "64")])
config.plugins.Boblight.setup                     = ConfigSelection(default = "0", choices = [("0", "0"), ("1", "1")])
config.plugins.Boblight.chasemode                 = ConfigOnOff(default=False)
config.plugins.Boblight.cluster                   = ConfigSelection(default = "1", choices = [("1", "1"),("2", "2"),("3", "3"),("4", "4"),("5", "5"),("6", "6"),("7", "7"),("8", "8"),("9", "9"),("10", "10")])

config.plugins.Boblight.autostart                 = ConfigOnOff(default=False)
config.plugins.Boblight.presets                   = ConfigSelection(default = "1", choices = [
("0", _("Custom Profile 0")),("1", _("Custom Profile 1")),("2", _("Custom Profile 2")), ("3", _("Custom Profile 3")), ("4", _("Custom Profile 4")),("5", _("Custom Profile 5")),
("6", _("Custom Profile 6"))])


config.plugins.Boblight.interval = ConfigSelection(default = "0.10", choices = [
("0.01", "0.01"), ("0.02", "0.02"), ("0.03", "0.03"), ("0.04", "0.04"),("0.05", "0.05"),("0.06", "0.06"), ("0.07", "0.07"), ("0.08", "0.08"),("0.09", "0.09"),("0.10", "0.10"),("0.11", "0.11"),("0.12", "0.12"),("0.13", "0.13"),("0.14", "0.14"),("0.15", "0.15"),("0.16", "0.16"),("0.17", "0.17"),("0.18", "0.18"),("0.19", "0.19")
,("0.20", "0.20"),("0.21", "0.21"),("0.22", "0.22"),("0.23", "0.23"),("0.24", "0.24"),("0.25", "0.25"),("0.26", "0.26"),("0.27", "0.27"),("0.28", "0.28"),("0.29", "0.29"),("0.30", "0.30"),("0.31", "0.31"),("0.32", "0.32"),("0.33", "0.33"),("0.34", "0.34"),("0.35", "0.35"),("0.36", "0.36"),("0.37", "0.37"),("0.38", "0.38"),("0.39", "0.39")
,("0.40", "0.40"),("0.41", "0.41"),("0.42", "0.42"),("0.43", "0.43"),("0.44", "0.44"),("0.45", "0.45"),("0.46", "0.46"),("0.47", "0.47"),("0.48", "0.48"),("0.49", "0.49")
,("0.50", "0.50")])

config.plugins.Boblight.saturation = ConfigSelection(default = "1.0", choices = [
("0.0", "0.0"),("0.1", "0.1"), ("0.2", "0.2"), ("0.3", "0.3"),("0.4", "0.4"),("0.5", "0.5"), 
("0.6", "0.6"),("0.7", "0.7"),("0.8", "0.8"),("0.9", "0.9"), ("1.0", "1.0"), ("1.1", "1.1"), ("1.2", "1.2"), ("1.3", "1.3"),("1.4", "1.4"),("1.5", "1.5"), ("1.6", "1.6"), 
("1.7", "1.7"),("1.8", "1.8"),("1.9", "1.9"), ("2.0", "2.0"), ("2.1", "2.1"),("2.2", "2.2"),("2.3", "2.3"), ("2.4", "2.4"), ("2.5", "2.5"),("2.6", "2.6"),("2.7", "2.7"), 
("2.8", "2.8"),("2.9", "2.9"),("3.0", "3.0"),("3.1", "3.1"),("3.2", "3.2"),("3.3", "3.3"), ("3.4", "3.4"), 
("3.5", "3.5"),("3.6", "3.6"),("3.7", "3.7"), ("3.8", "3.8"),("3.9", "3.9"),("4.0", "4.0"),("4.1", "4.1"),("4.2", "4.2"),("4.3", "4.3"), ("4.4", "4.4"), ("4.5", "4.5"),
("4.6", "4.6"),("4.7", "4.7"), ("4.8", "4.8"),("4.9", "4.9"),("5.0", "5.0"),("5.1", "5.1"), ("5.2", "5.2"), ("5.3", "5.3"),("5.4", "5.4"),
("5.5", "5.5"),("5.6", "5.6"), ("5.7", "5.7"),("5.8", "5.8"),("5.9", "5.9"), ("6.0", "6.0"), ("6.1", "6.1"),("6.2", "6.2"),("6.3", "6.3"), 
("6.4", "6.4"),("6.5", "6.5"),("6.6", "6.6"),("6.7", "6.7"), ("6.8", "6.8"),("6.9", "6.9"),("7.0", "7.0"),("7.1", "7.1"),("7.2", "7.2"),
("7.3", "7.3"),("7.4", "7.4"), ("7.5", "7.5"),("7.6", "7.6"),("7.7", "7.7"), ("7.8", "7.8"),("7.9", "7.9"),("8.0", "8.0"),("8.1", "8.1"),
("8.2", "8.2"),("8.3", "8.3"), ("8.4", "8.4"), ("8.5", "8.5"),("8.6", "8.6"),("8.7", "8.7"), ("8.8", "8.8"),("8.9", "8.9"),("9.0", "9.0"),
("9.1", "9.1"),("9.2", "9.2"),("9.3", "9.3"), ("9.4", "9.4"), ("9.5", "9.5"),("9.6", "9.6"),("9.7", "9.7"), ("9.8", "9.8"),("9.9", "9.9"),
("10.0", "10.0"),("10.1", "10.1"), ("10.2", "10.2"), ("10.3", "10.3"),("10.4", "10.4"),("10.5", "10.5"), ("10.6", "10.6"), ("10.7", "10.7"),("10.8", "10.8"),("10.9", "10.9"), 
("11.0", "11.0"), ("11.1", "11.1"),("11.2", "11.2"),("11.3", "11.3"), ("11.4", "11.4"), ("11.5", "11.5"),("11.6", "11.6"),("11.7", "11.7"), ("11.8", "11.8"),
("11.9", "11.9"),("12.0", "12.0"),("12.1", "12.1"),("12.2", "12.2"),("12.3", "12.3"), ("12.4", "12.4"), ("12.5", "12.5"),("12.6", "12.6"),("12.7", "12.7"), 
("12.8", "12.8"),("12.9", "12.9"),("13.0", "13.0"),("13.1", "13.1"),("13.2", "13.2"),("13.3", "13.3"), ("13.4", "13.4"), ("13.5", "13.5"),("13.6", "13.6"),
("13.7", "13.7"),("13.8", "13.8"),("14.9", "13.9"),("14.0", "14.0"),("14.1", "14.1"),("14.2", "14.2"),("14.3", "14.3"), ("14.4", "14.4"), ("14.5", "14.5"),
("14.6", "14.6"),("14.7", "14.7"), ("14.8", "14.8"),("14.9", "14.9"),("15.0", "15.0"),("15.1", "15.1"),("15.2", "15.2"),("15.3", "15.3"), ("15.4", "15.4"), 
("15.5", "15.5"),("15.6", "15.6"),("15.7", "15.7"), ("15.8", "15.8"),("15.9", "15.9"),("16.0", "16.0"),("16.1", "16.1"),("16.2", "16.2"),("16.3", "16.3"), 
("16.4", "16.4"),("16.5", "16.5"),("16.6", "16.6"),("16.7", "16.7"), ("16.8", "16.8"),("16.9", "16.9"),("17.0", "17.0"),("17.1", "17.1"),("17.2", "17.2"),
("17.3", "17.3"),("17.4", "17.4"), ("17.5", "17.5"),("17.6", "17.6"),("17.7", "17.7"), ("17.8", "17.8"),("17.9", "17.9"),("18.0", "18.0"),("18.1", "18.1"),
("18.2", "18.2"),("18.3", "18.3"), ("18.4", "18.4"), ("18.5", "18.5"),("18.6", "18.6"),("18.7", "18.7"), ("18.8", "18.8"),("18.9", "18.9"),("19.0", "19.0"),
("19.1", "19.1"),("19.2", "19.2"),("19.3", "19.3"), ("19.4", "19.4"), ("19.5", "19.5"),("19.6", "19.6"),("19.7", "19.7"), ("19.8", "19.8"),("19.9", "19.9"),
("20.0", "20.0")])

config.plugins.Boblight.valuemin = ConfigSelection(default = "0.00", choices = [
("0.00", "0.00"), ("0.01", "0.01"), ("0.02", "0.02"), ("0.03", "0.03"),
("0.04", "0.04"),("0.05", "0.05"), ("0.06", "0.06"), ("0.07", "0.07"),("0.08", "0.08"),("0.09", "0.09"),("0.1", "0.1"), ("0.2", "0.2"), 
("0.3", "0.3"),("0.4", "0.4"),("0.5", "0.5"), ("0.6", "0.6"), ("0.7", "0.7"),("0.8", "0.8"),("0.9", "0.9"), 
("1.0", "1.0")])

config.plugins.Boblight.valuemax = ConfigSelection(default = "1.0", choices = [
("0.00", "0.00"), ("0.01", "0.01"), ("0.02", "0.02"), ("0.03", "0.03"),
("0.04", "0.04"),("0.05", "0.05"), ("0.06", "0.06"), ("0.07", "0.07"),("0.08", "0.08"),("0.09", "0.09"),("0.1", "0.1"), 
("0.2", "0.2"), ("0.3", "0.3"),("0.4", "0.4"),("0.5", "0.5"), ("0.6", "0.6"), ("0.7", "0.7"),("0.8", "0.8"),("0.9", "0.9"), 
("1.0", "1.0")])

config.plugins.Boblight.gamma = ConfigSelection(default = "2.2", choices = [
("1.0", "1.0"),("1.1", "1.1"), ("1.2", "1.2"), ("1.3", "1.3"),("1.4", "1.4"),
("1.5", "1.5"),("1.6", "1.6"), ("1.7", "1.7"),("1.8", "1.8"),("1.9", "1.9"), ("2.0", "2.0"), ("2.1", "2.1"),("2.2", "2.2"),("2.3", "2.3"), 
("2.4", "2.4"),("2.5", "2.5"),("2.6", "2.6"),("2.7", "2.7"), ("2.8", "2.8"),("2.9", "2.9"),("3.0", "3.0"),
("3.1", "3.1"),("3.2", "3.2"),("3.3", "3.3"), ("3.4", "3.4"), ("3.5", "3.5"),("3.6", "3.6"),("3.7", "3.7"), ("3.8", "3.8"),("3.9", "3.9"),("4.0", "4.0"),("4.1", "4.1"),
("4.2", "4.2"),("4.3", "4.3"), ("4.4", "4.4"), ("4.5", "4.5"),("4.6", "4.6"),("4.7", "4.7"), ("4.8", "4.8"),
("4.9", "4.9"),("5.0", "5.0"),("5.1", "5.1"), ("5.2", "5.2"), ("5.3", "5.3"),("5.4", "5.4"),("5.5", "5.5"), ("5.6", "5.6"), ("5.7", "5.7"),("5.8", "5.8"),("5.9", "5.9"), 
("6.0", "6.0"),("6.1", "6.1"),("6.2", "6.2"),("6.3", "6.3"), ("6.4", "6.4"), ("6.5", "6.5"),("6.6", "6.6"),("6.7", "6.7"), ("6.8", "6.8"),("6.9", "6.9"),("7.0", "7.0"),
("7.1", "7.1"),("7.2", "7.2"),("7.3", "7.3"), ("7.4", "7.4"), ("7.5", "7.5"),("7.6", "7.6"),("7.7", "7.7"), ("7.8", "7.8"),("7.9", "7.9"),("8.0", "8.0"),
("8.1", "8.1"),("8.2", "8.2"),("8.3", "8.3"), ("8.4", "8.4"), ("8.5", "8.5"),("8.6", "8.6"),("8.7", "8.7"), ("8.8", "8.8"),("8.9", "8.9"),
("9.0", "9.0"),("9.1", "9.1"),("9.2", "9.2"),("9.3", "9.3"), ("9.4", "9.4"), ("9.5", "9.5"),("9.6", "9.6"),("9.7", "9.7"), ("9.8", "9.8"),("9.9", "9.9"),
("10.0", "10.0")
])

config.plugins.Boblight.saturationmin = ConfigSelection(default = "0.0", choices = [
("0.00", "0.00"), ("0.01", "0.01"), ("0.02", "0.02"), ("0.03", "0.03"),("0.04", "0.04"),("0.05", "0.05"), ("0.06", "0.06"), ("0.07", "0.07"),("0.08", "0.08"),
("0.09", "0.09"),("0.1", "0.1"), ("0.2", "0.2"), ("0.3", "0.3"),("0.4", "0.4"),("0.5", "0.5"), ("0.6", "0.6"), ("0.7", "0.7"),("0.8", "0.8"),("0.9", "0.9"), 
("1.0", "1.0")])

config.plugins.Boblight.saturationmax = ConfigSelection(default = "1.0", choices = [
("0.00", "0.00"), ("0.01", "0.01"), ("0.02", "0.02"), ("0.03", "0.03"),
("0.04", "0.04"),("0.05", "0.05"), ("0.06", "0.06"), ("0.07", "0.07"),("0.08", "0.08"),
("0.09", "0.09"),("0.1", "0.1"), ("0.2", "0.2"), ("0.3", "0.3"),("0.4", "0.4"),("0.5", "0.5"), ("0.6", "0.6"), ("0.7", "0.7"),("0.8", "0.8"),("0.9", "0.9"), 
("1.0", "1.0")])

config.plugins.Boblight.value          = ConfigSlider(default=1, increment=1, limits=(0,20))
config.plugins.Boblight.speed          = ConfigSlider(default=100, increment=1, limits=(0,100))
config.plugins.Boblight.chase_speed    = ConfigSlider(default=60, increment=1, limits=(0,100))
config.plugins.Boblight.autospeed      = ConfigSlider(default=0, increment=1, limits=(0,100))
config.plugins.Boblight.interpolation  = ConfigOnOff(default=False)
config.plugins.Boblight.blackbar       = ConfigOnOff(default=False)

config.plugins.Boblight.hscanstart     = ConfigSlider(default=0, increment=2, limits=(0,100))
config.plugins.Boblight.hscanend       = ConfigSlider(default=0, increment=2, limits=(0,100))
config.plugins.Boblight.vscanstart     = ConfigSlider(default=0, increment=2, limits=(0,100))
config.plugins.Boblight.vscanend       = ConfigSlider(default=0, increment=2, limits=(0,100))


config.plugins.Boblight.type                    = ConfigSelection(default = "Atmolight", choices = [
	("Adalight/Momo", "Adalight/Momo"),
	("Ambioder", "Ambioder"),
	("Atmolight", "Atmolight"),
	("Karatelight", "Karatelight"),
	("Lightpack1", "Lightpack Firmware < 6.2"),
	("Lightpack2", "Lightpack Firmware 6.3 >"),
	("Oktolight", "Oktolight"),
	("Sedulight 5A A0 A5", "Sedulight 96 channels"),
	("Sedulight 5A A1 A5", "Sedulight 256 channels"),
	("Sedulight 5A A2 A5", "Sedulight 512 channels"),
	("Sedulight 5A B0 A5", "Sedulight 768 channels"),
	("Adalight/Momo", "Adalight/Momo"),
	("iBelight", "iBelight")])

# 03eb:204f <-lightpack device
config.plugins.Boblight.serial                   = ConfigSelection(default = "5437231893F351C11700", choices = [
	("5437231893F351C11700", "5437231893F351C11700"),
	("649323139323515111C0", "649323139323515111C0")])

config.plugins.Boblight.bus                     = ConfigInteger(1,(1, 9))
config.plugins.Boblight.laddress                = ConfigInteger(6,(1, 9))

config.plugins.Boblight.output                  = ConfigDirectory(default="/dev/ttyUSB0")
config.plugins.Boblight.rate                    = ConfigInteger(057600,(0, 500000))
config.plugins.Boblight.lights_left             = ConfigInteger(0,(0, 99))
config.plugins.Boblight.lights_top              = ConfigInteger(0,(0, 99))
config.plugins.Boblight.lights_right            = ConfigInteger(0,(0, 99))
config.plugins.Boblight.lights_bottom           = ConfigInteger(0,(0, 99))
config.plugins.Boblight.lights_bottom_right     = ConfigInteger(0,(0, 99))
config.plugins.Boblight.lights_bottom_left      = ConfigInteger(0,(0, 99))
config.plugins.Boblight.lights_bottom_center    = ConfigInteger(0,(0, 50))

config.plugins.Boblight.scanl          = ConfigInteger(10,(0, 100))
config.plugins.Boblight.scanr          = ConfigInteger(10,(0, 100))
config.plugins.Boblight.scant          = ConfigInteger(10,(0, 100))
config.plugins.Boblight.scanb          = ConfigInteger(10,(0, 100))
config.plugins.Boblight.color          = ConfigSelection(default = "rgb", choices = [("rgb", "RGB"), ("bgr", "BGR")])
config.plugins.Boblight.begincount     = ConfigSelection(default = "left-bottom", choices = [("left-bottom", "LEFT [bottom]"), ("left-top", "LEFT [top]"), ("top-left", "TOP [left]"), ("top-right", "TOP [right]"), ("right-top", "RIGHT [top]"), ("right-bottom", "RIGHT [bottom]"), ("bottom-right", "BOTTOM [right]"), ("bottom-middle", "BOTTOM [middle]"), ("bottom-left", "BOTTOM [left]")])
config.plugins.Boblight.clockwise      = ConfigSelection(default = "1", choices = [("1", "Clockwise"), ("2", "Backwards")])
config.plugins.Boblight.floorstand     = ConfigSelection(default = "1", choices = [("1", "No"), ("2", "Yes")])
config.plugins.Boblight.blacklevel     = ConfigFloat(default = [0,0], limits = [(0,9),(0,99)])
config.plugins.Boblight.overlap        = ConfigOnOff(default=False)
config.plugins.Boblight.precision      = ConfigInteger(255,(0, 255))

config.plugins.Boblight.lastmode       = ConfigText(default = "-", fixed_size=10)
config.plugins.Boblight.m_3dmode       = ConfigSelection(default = "1", choices = [("1", "Disabled"), ("2", "Top and Bottom"), ("3", "SidebySide")])

config.plugins.Boblight.config_r_adjust         = ConfigFloat(default = [1,00], limits = [(0,9),(00,99)])
config.plugins.Boblight.config_r_gamma          = ConfigFloat(default = [0,91], limits = [(0,9),(00,99)])
config.plugins.Boblight.config_r_blacklevel     = ConfigFloat(default = [0,00], limits = [(0,9),(00,99)])

config.plugins.Boblight.config_g_adjust         = ConfigFloat(default = [0,96], limits = [(0,9),(00,99)])
config.plugins.Boblight.config_g_gamma          = ConfigFloat(default = [0,86], limits = [(0,9),(00,99)])
config.plugins.Boblight.config_g_blacklevel     = ConfigFloat(default = [0,00], limits = [(0,9),(00,99)])

config.plugins.Boblight.config_b_adjust         = ConfigFloat(default = [0,80], limits = [(0,9),(00,99)])
config.plugins.Boblight.config_b_gamma          = ConfigFloat(default = [0,95], limits = [(0,9),(00,99)])
config.plugins.Boblight.config_b_blacklevel     = ConfigFloat(default = [0,00], limits = [(0,9),(00,99)])

config.plugins.Boblight.timer_standby_onoff     = ConfigOnOff(default=False)
config.plugins.Boblight.timer_onoff             = ConfigOnOff(default=False)
config.plugins.Boblight.time_start              = ConfigClock(default=def_start)
config.plugins.Boblight.time_end                = ConfigClock(default=def_end)

config.plugins.Boblight.brightness_timer_onoff  = ConfigOnOff(default=False)
config.plugins.Boblight.brightness_time_start   = ConfigClock(default=def_start)
config.plugins.Boblight.brightness_time_end     = ConfigClock(default=def_end)
config.plugins.Boblight.message_onoff           = ConfigOnOff(default=False)
config.plugins.Boblight.m_delay                 = ConfigSlider(default=0, increment=1, limits=(0,20))

m_socket = BobSocket() 		# Socket class for anroid app
m_timer = BobTimer() 		# Timer class
m_bob = m_socket.m_bob		# Boblight class

if m_bob.getStatus() == 1:        
    #send current config to client and close socket
    m_bob.sendAll()
    m_bob.closeSocket()
	
#Start threads
m_timer.start()
m_socket.start()

global m_fps

#Get width and height from screen
DESKTOP_WIDTH       = getDesktop(0).size().width()
DESKTOP_HEIGHT      = getDesktop(0).size().height()
BOBLIST_MAIN        = 0
BOBLIST_COLOR       = 1
BOBLIST_NETWORK     = 2
BOBLIST_MOODLAMP    = 3
BOBLIST_TITLES      = [ _("Mainmenu"), _("Color tuning"), _("Network settings"), _("Moodlamp settings") ]

pluginversion       = config.plugins.Boblight.version.value

#Standby notifier
config.misc.standbyCounter.addNotifier(m_bob.enterStandby, initial_call = False)

################
#
# Helpers
#
################

def setArch():
    if config.plugins.Boblight.arch.value is "":
        fo = open("/home/boblight-addons/arch.txt", "r")
        reading = fo.read(1000)
        fo.close()

        config.plugins.Boblight.arch.value = str(reading)
        config.plugins.Boblight.arch.save()
        configfile.save() #save to file
    print ("[Boblight] Arch: " + config.plugins.Boblight.arch.value)

def getAspect():
    val = AVSwitch().getAspectRatioSetting()
    return val/2
    
def RGB(r,g,b):
    return (r<<16)|(g<<8)|b

def Clamp(value,minv,maxv):
    if value > maxv:
        value = maxv
    elif value < minv:
        value = minv
    return value

def error(session, error):
    session.open(MessageBox,("UNEXPECTED ERROR:\n%s") % (error),  MessageBox.TYPE_INFO)
		
################
#
# Light switch
#
################    
def DaemonToggle(session, **kwargs):
    fil = os.path.isfile("/etc/boblight.conf")
    if fil == True:
        ret = m_bob.getStatus()
        if ret == 0:            
            m_bob.Lights_on(session)
        elif ret == 1:
            m_bob.Lights_off(session)
        
    else:
        self.session.open(MessageBox, _(boblightconf_notfound), MessageBox.TYPE_WARNING, timeout=4) 
        
def LightToggle(session, **kwargs):

    if config.plugins.Boblight.mode.getValue() == str(2):
        if config.plugins.Boblight.moodlamp_mode.getValue() == str(1):
            if config.plugins.Boblight.color.getValue() == "rgb":
		color = tohex(config.plugins.Boblight.moodlamp_static_color_r.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_b.getValue())
	    elif config.plugins.Boblight.color.getValue() == "bgr":
		color = tohex(config.plugins.Boblight.moodlamp_static_color_b.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_r.getValue())
	    
            ret = m_bob.sendCommand("mode","static")
            ret = m_bob.sendCommand("static_color",str(color))  #set color
        elif config.plugins.Boblight.moodlamp_mode.getValue() == str(4):
            ret = m_bob.sendCommand("mode","colorfader")
            ret = m_bob.sendCommand("faderbrightness",str(config.plugins.Boblight.moodlamp_fader_brightness.getValue()))
            
        if ret == 0:
            msg = _("Error: can't send switch to [moodlamp], Maybe client is not running ?\n%s") %(m_bob.error)               
            session.open(MessageBox, _(msg), MessageBox.TYPE_WARNING)
        elif ret == 1:
            msg = _("Switch to mode: moodlamp")
            session.open(MessageBox, _(msg), MessageBox.TYPE_WARNING, timeout = 3) 
            config.plugins.Boblight.mode.setValue(str(1))
                 
    elif config.plugins.Boblight.mode.getValue() == str(1):
        ret = m_bob.sendCommand("mode","dynamic")
        
        if ret == 0:
            msg = _("Error: can't send switch to [dynamic], Maybe client is not running ?\n%s") %(m_bob.error)              
            session.open(MessageBox, _(msg), MessageBox.TYPE_WARNING)
        elif ret == 1:
            msg = _("Switch to mode: dynamic")                
            session.open(MessageBox, _(msg), MessageBox.TYPE_WARNING, timeout = 3) 
            config.plugins.Boblight.mode.setValue(str(1))
        config.plugins.Boblight.mode.setValue(str(2))
        
    config.plugins.Boblight.mode.save()
    
################
#
# Start Plugin
#
################

def main(session, **kwargs):
    print "[Boblight] start configuration"
    session.open(BoblightConfig)

def sessionstart(reason, **kwargs):
    if reason == 0:
        m_timer.gotSession(kwargs["session"])

def Plugins(**kwargs):
    return [PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart),
    PluginDescriptor(name=_('Boblight Enigma2'), description=_('TV backlight'), where=PluginDescriptor.WHERE_PLUGINMENU, icon='boblight.png', needsRestart = False, fnc=main),
    PluginDescriptor(name=_('Boblight | On / Off'), description=_('TV backlight'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='boblight.png', needsRestart = False, fnc=DaemonToggle),
    PluginDescriptor(name=_('Boblight | Main'), description=_('TV backlight'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='boblight.png', needsRestart = False, fnc=main),
    PluginDescriptor(name=_('Boblight | Moodlamp / Dynamic'), description=_('TV backlight'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='boblight.png', needsRestart = False, fnc=LightToggle)]


#Set archtype
setArch()

#
#
# Coloradjustment
#    
#

class BoblightAdjustScreen(Screen, ConfigListScreen):

    skin = """
        <screen name="BoblightAdjustScreen" position="%d,%d" size="350,320" title="%s" >	
        <widget name="config" position="10,5" size="330,280" zPosition="5" transparent="1" foregroundColor="white"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_green.png" zPosition="2"  position="10,270" size="35,29" alphatest="on" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_blue.png" zPosition="2"  position="130,270" size="35,29" alphatest="on" />
        <widget name="buttongreen" position="60,272" size="120,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
        <widget name="buttonblue" position="180,272" size="180,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>		
	</screen>""" % ((DESKTOP_WIDTH - 350) / 2, (DESKTOP_HEIGHT - 300) / 2,_("Boblight.conf RGB Adjust"),)

    def __init__(self,session):
        self.session = session
        Screen.__init__(self, session)
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)

        self["buttongreen"] = Label(_("Close"))
        self["buttonblue"] = Label(_("Default"))             
        self["moodActions"] = ActionMap(["BoblightActions"],
            {
            	"ok":		self.keyOk,
            	"green":	self.keyOk,
            	"blue":		self.keyBlue,
            	"cancel":   self.close
            }, -2)
        
    def createConfigList(self):
        self.list = []
        if config.plugins.Boblight.color.value == "rgb":
            self.list.append(getConfigListEntry(_('Red ColorAdjust:'), config.plugins.Boblight.config_r_adjust))	      
            self.list.append(getConfigListEntry(_('Red Gamma:'), config.plugins.Boblight.config_r_gamma))	
            self.list.append(getConfigListEntry(_('Red Blacklevel:'), config.plugins.Boblight.config_r_blacklevel))	
            self.list.append(getConfigListEntry(_('Green ColorAdjust:'), config.plugins.Boblight.config_g_adjust))	
            self.list.append(getConfigListEntry(_('Green Gamma:'), config.plugins.Boblight.config_g_gamma))	
            self.list.append(getConfigListEntry(_('Green Blacklevel:'), config.plugins.Boblight.config_g_blacklevel))	
            self.list.append(getConfigListEntry(_('Blue ColorAdjust:'), config.plugins.Boblight.config_b_adjust))	
            self.list.append(getConfigListEntry(_('Blue Gamma:'), config.plugins.Boblight.config_b_gamma))	
            self.list.append(getConfigListEntry(_('Blue Blacklevel:'), config.plugins.Boblight.config_b_blacklevel))	
        elif config.plugins.Boblight.color.value == "bgr":
            self.list.append(getConfigListEntry(_('Blue ColorAdjust:'), config.plugins.Boblight.config_r_adjust))	      
            self.list.append(getConfigListEntry(_('Blue Gamma:'), config.plugins.Boblight.config_r_gamma))	
            self.list.append(getConfigListEntry(_('Blue Blacklevel:'), config.plugins.Boblight.config_r_blacklevel))	
            self.list.append(getConfigListEntry(_('Green ColorAdjust:'), config.plugins.Boblight.config_g_adjust))	
            self.list.append(getConfigListEntry(_('Green Gamma:'), config.plugins.Boblight.config_g_gamma))	
            self.list.append(getConfigListEntry(_('Green Blacklevel:'), config.plugins.Boblight.config_g_blacklevel))	
            self.list.append(getConfigListEntry(_('Red ColorAdjust:'), config.plugins.Boblight.config_b_adjust))	
            self.list.append(getConfigListEntry(_('Red Gamma:'), config.plugins.Boblight.config_b_gamma))	
            self.list.append(getConfigListEntry(_('Red Blacklevel:'), config.plugins.Boblight.config_b_blacklevel))
            
    def changedEntry(self):
        self.createConfigList()
        self["config"].setList(self.list)

    def save(self):
        for x in self['config'].list:
            x[1].save()
        self.changedEntry() #Refresh list
        configfile.save() #save to file
    
    def keyOk(self):
        self.save()
        self.session.open(MessageBox, _("Do not forget to create a new configfile for the changes to take effect."), MessageBox.TYPE_INFO, timeout=10)
        self.close()
    
    def keyBlue(self):
    	self.revert()
    	
    def revert(self):
        self.session.openWithCallback(self.keyYellowConfirm, MessageBox, _("Reset settings to defaults?"), MessageBox.TYPE_YESNO, timeout = 20, default = True)

    def keyYellowConfirm(self, confirmed):
        if not confirmed:
            print "[Boblight] Reset to defaults not confirmed."
        else:
            print "[Boblight] Setting Configuration to defaults."
            config.plugins.Boblight.config_r_adjust.value[0] = 1
            config.plugins.Boblight.config_r_adjust.value[1] = 0
            config.plugins.Boblight.config_r_gamma.value[0] = 0
            config.plugins.Boblight.config_r_gamma.value[1] = 91           
            config.plugins.Boblight.config_r_blacklevel.value[0] = 0
            config.plugins.Boblight.config_r_blacklevel.value[1] = 0
            
            config.plugins.Boblight.config_g_adjust.value[0] = 0
            config.plugins.Boblight.config_g_adjust.value[1] = 96
            config.plugins.Boblight.config_g_gamma.value[0] = 0
            config.plugins.Boblight.config_g_gamma.value[1] = 86           
            config.plugins.Boblight.config_g_blacklevel.value[0] = 0
            config.plugins.Boblight.config_g_blacklevel.value[1] = 0
            
            config.plugins.Boblight.config_b_adjust.value[0] = 0
            config.plugins.Boblight.config_b_adjust.value[1] = 80
            config.plugins.Boblight.config_b_gamma.value[0] = 0
            config.plugins.Boblight.config_b_gamma.value[1] = 95           
            config.plugins.Boblight.config_b_blacklevel.value[0] = 0
            config.plugins.Boblight.config_b_blacklevel.value[1] = 0

            self.save()

#
#
# DeviceBrowser
#    
#
            
class DeviceBrowser(Screen):
    skin = """
		<screen name="DeviceBrowser" position="%d,%d" size="450,380" title="%s" >
            <widget name="label"    position="0,0"  size="450,18" font="Regular;15" transparent="1"/>
            <ePixmap name="div" pixmap="skin_default/div-h.png" position="0,19"  size="450,2" zPosition="4" transparent="1"/>
            <widget name="filelist" position="0,21" size="450,319" scrollbarMode="showOnDemand" zPosition="1"/>
            <ePixmap name="r" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_red.png"    position="5,347"   size="35,29" zPosition="4" transparent="1" alphatest="on"/>
            <ePixmap name="g" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_green.png"  position="305,347" size="35,29" zPosition="4" transparent="1" alphatest="on"/>
            <widget name="key_r" position="40,340"  size="110,40" valign="center" halign="left"  zPosition="5" transparent="1" foregroundColor="white" font="Regular;16"/>
            <widget name="key_g" position="340,340" size="110,40" valign="center" halign="right" zPosition="5" transparent="1" foregroundColor="white" font="Regular;16"/>
		</screen>""" % (
            (DESKTOP_WIDTH - 450) / 2, (DESKTOP_HEIGHT - 380) / 2, # position
            _("Device")
            )

    def __init__(self, session, currentDevice = None):
        Screen.__init__(self, session)

        self.filelist = FileList("/dev/", showDirectories = True, showFiles = True, showMountpoints = True, isTop = False, matchingPattern = "")
        if currentDevice is not None:
            self.filelist.changeDir(currentDevice.rsplit('/', 1)[0] + "/", select = currentDevice.rsplit('/', 1)[1])
            self.filelist.isTop = self.filelist.getCurrentDirectory() == "/dev/"
            self.filelist.refresh()
        self["key_r"] = Button(_("Cancel"))
        self["key_g"] = Button(_("Select"))
        self["filelist"] = self.filelist
        self["label"] = Label(self["filelist"].getCurrentDirectory())

        self["FilelistActions"] = ActionMap(["BoblightActions"],
            {
                "ok":     self.KeyOk,
                "cancel": self.KeyExit,
                "red":    self.KeyOk,
                "green":  self.KeyExit
            })

    def KeyOk(self):
        if self.filelist.canDescent():
            self.filelist.descent()
            self.filelist.isTop = self.filelist.getCurrentDirectory() == "/dev/"
            self.filelist.refresh()
            self["label"].setText(self.filelist.getCurrentDirectory())
        else:
            myDevice = "%s/%s" % (self.filelist.getCurrentDirectory(), self.filelist.getFilename())
            self.close( myDevice.replace("//", "/") )
            
    def KeyExit(self):
        self.close(False)

#
#
# DeviceConfig
#    
#

class DeviceConfigScreen(Screen, ConfigListScreen):

    skin = """
        <screen name="DeviceConfigScreen" position="%d,%d" size="1050,470" title="Config editor" >	
        <ePixmap pixmap="skin_default/div-v.png" position="520,10" size="1,420" zPosition="4" transparent="1" alphatest="on"/>
        <widget name="config" position="10,5" size="500,430" zPosition="5" transparent="1" foregroundColor="white"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_green.png" zPosition="2"  position="10,435" size="35,29" alphatest="on" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_yellow.png" zPosition="2"  position="190,435" size="35,29" alphatest="on" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_blue.png" zPosition="2"  position="290,435" size="35,29" alphatest="on" />
		
        <widget name="pic_leftb" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/left-bottom.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_leftt" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/left-top.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_topl" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/top-left.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_topr" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/top-right.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_rightt" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/right-top.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_rightb" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/right-bottom.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_botr" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/bottom-right.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_botl" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/bottom-left.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_botmb" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/bottom-middle-back.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_botmc" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/bottom-middle-clock.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>        
        <widget name="pic_floor" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/floorstand.png" position="540,8" size="500,387" zPosition="5" transparent="1" alphatest="on"/>
        <widget name="pic_tv" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/tv.png" position="540,8" size="500,387" zPosition="4" transparent="1" alphatest="on"/>
        <widget name="pic_blocks_f" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/blocks-floor.png" position="540,8" size="500,387" zPosition="10" transparent="1" alphatest="on"/>
        <widget name="pic_blocks_nof" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/blocks-nofloor.png" position="540,8" size="500,387" zPosition="10" transparent="1" alphatest="on"/>

        <widget name="wrong" position="615,150" size="350,50" valign="center" halign="center" zPosition="13" foregroundColor="red" transparent="1" font="Regular;18"/>
        <widget name="leds-top" position="763,11" size="50,50" valign="center" halign="center" zPosition="11" foregroundColor="white" transparent="1" font="Regular;18"/>
        <widget name="leds-right" position="540,163" size="50,50" valign="center" halign="center" zPosition="11" foregroundColor="white" transparent="1" font="Regular;18"/>
        <widget name="leds-bottom" position="763,304" size="50,50" valign="center" halign="center" zPosition="11" foregroundColor="white" transparent="1" font="Regular;18"/>
        <widget name="leds-bottom-left" position="641,313" size="50,50" valign="center" halign="center" zPosition="11" foregroundColor="white" transparent="1" font="Regular;18"/>
        <widget name="leds-bottom-right" position="881,313" size="50,50" valign="center" halign="center" zPosition="11" foregroundColor="white" transparent="1" font="Regular;18"/>       
        <widget name="leds-left" position="988,163" size="50,50" valign="center" halign="center" zPosition="11" foregroundColor="white" transparent="1" font="Regular;18"/>
        <widget name="channels" position="615,230" size="350,50" valign="center" halign="center" zPosition="11" foregroundColor="blue" transparent="1" font="Regular;18"/>
        
        <widget name="buttongreen" position="50,437" size="150,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
        <widget name="buttonyellow" position="230,437" size="80,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
        <widget name="buttonblue" position="330,437" size="150,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
        		        
		</screen>""" % (
            (DESKTOP_WIDTH - 1050) / 2, (DESKTOP_HEIGHT - 470) / 2)

    def __init__(self,session):
        self.session = session
        Screen.__init__(self, session)
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)        
        self.createfile   = False
        
        self.begin = None
        self.floor = None
        self.seqq  = None
        self.leds_top = None
        self.leds_right = None
        self.leds_left = None
        self.leds_bottom = None
        self.leds_bottom_left = None
        self.leds_bottom_right = None
        self.leds_bottom_center = None
        self.channels = None
        self.total = None
        
        #self["Canvas"] = CanvasSource()
        self["pic_tv"] = Pixmap()
        self["pic_leftb"] = Pixmap()
        self["pic_leftb"].hide()
        self["pic_leftt"] = Pixmap()
        self["pic_leftt"].hide()
        self["pic_topl"] = Pixmap()
        self["pic_topl"].hide()
        self["pic_topr"] = Pixmap()
        self["pic_topr"].hide()
        self["pic_rightt"] = Pixmap()
        self["pic_rightt"].hide()
        self["pic_rightb"] = Pixmap()
        self["pic_rightb"].hide()
        self["pic_botr"] = Pixmap()
        self["pic_botr"].hide()
        self["pic_botmb"] = Pixmap()
        self["pic_botmb"].hide()
        self["pic_botmc"] = Pixmap()
        self["pic_botmc"].hide()
        self["pic_botl"] = Pixmap()
        self["pic_botl"].hide()    
        self["pic_floor"] = Pixmap()
        self["pic_floor"].hide()
        
        self["pic_blocks_f"] = Pixmap()
        self["pic_blocks_f"].hide()
        self["pic_blocks_nof"] = Pixmap()
        self["pic_blocks_nof"].hide()
                
        self.current = None
        
        self["wrong"] = Label(_(""))
        self["leds-top"] = Label(_(str(config.plugins.Boblight.lights_top.value)))
        self["leds-bottom"] = Label(_(str(config.plugins.Boblight.lights_bottom.value)))
        self["leds-bottom-left"] = Label(_(str(config.plugins.Boblight.lights_bottom_left.value)))
        self["leds-bottom-right"] = Label(_(str(config.plugins.Boblight.lights_bottom_right.value)))
        self["leds-right"] = Label(_(str(config.plugins.Boblight.lights_right.value)))
        self["leds-left"] = Label(_(str(config.plugins.Boblight.lights_left.value)))
        self["channels"] = Label(_(""))
        self["buttongreen"] = Label(_("Create boblight.conf"))
        self["buttonyellow"] = Label(_("Test"))
        self["buttonblue"] = Label(_("RGB Adjust"))
        self["DeviceActions"] = ActionMap(["BoblightActions"],
            {
            	"cancel":	self.close,
            	"ok": 		self.keyOk,
            	"green":	self.keyGreen,            	
            	"yellow":	self.keyTest,
            	"blue":		self.keyBlue
            }, -2)

        self.setTv()
        self.current.show()
        
    def createConfigList(self):
        self.list = []  
        self.list.append(getConfigListEntry(_('Device type:'), config.plugins.Boblight.type))

	if config.plugins.Boblight.type.value == "Lightpack1":
	    self.list.append(getConfigListEntry(_('Bus:'), config.plugins.Boblight.bus))
	    self.list.append(getConfigListEntry(_('Address:'), config.plugins.Boblight.laddress))
	elif config.plugins.Boblight.type.value == "Lightpack2":
	    self.list.append(getConfigListEntry(_('Serial:'), config.plugins.Boblight.serial))
	else:
	    self.list.append(getConfigListEntry(_('Device output:'), config.plugins.Boblight.output))
	    self.list.append(getConfigListEntry(_('Device rate:'), config.plugins.Boblight.rate))

        self.list.append(getConfigListEntry(_('Color sequence:'), config.plugins.Boblight.color))
        
        if config.plugins.Boblight.type.value == "Ambioder":            
            self.list.append(getConfigListEntry(_('Ambioder precision:'), config.plugins.Boblight.precision))
        else:                       
            self.list.append(getConfigListEntry(_('With (floor) stand:'), config.plugins.Boblight.floorstand))        
            self.list.append(getConfigListEntry(_('How many lights at Top:'), config.plugins.Boblight.lights_top))
            self.list.append(getConfigListEntry(_('How many lights at Left:'), config.plugins.Boblight.lights_left))
            self.list.append(getConfigListEntry(_('How many lights at Right:'), config.plugins.Boblight.lights_right))                                   

            if config.plugins.Boblight.floorstand.value == str(2):
                self.list.append(getConfigListEntry(_('How many lights at Bottom-left:'), config.plugins.Boblight.lights_bottom_left))
                self.list.append(getConfigListEntry(_('Bottom center (how many places are empty):'), config.plugins.Boblight.lights_bottom_center))
                self.list.append(getConfigListEntry(_('How many lights at Bottom-right:'), config.plugins.Boblight.lights_bottom_right))
            else:
                self.list.append(getConfigListEntry(_('How many lights at Bottom:'), config.plugins.Boblight.lights_bottom))                       
            
            self.list.append(getConfigListEntry(_('Where begin to count:'), config.plugins.Boblight.begincount))
            self.list.append(getConfigListEntry(_('Clockwise or backwards:'), config.plugins.Boblight.clockwise))
            self.list.append(getConfigListEntry(_('Scan margin Left:'), config.plugins.Boblight.scanl))
            self.list.append(getConfigListEntry(_('Scan margin Right:'), config.plugins.Boblight.scanr))
            self.list.append(getConfigListEntry(_('Scan margin Top:'), config.plugins.Boblight.scant))
            self.list.append(getConfigListEntry(_('Scan margin Bottom:'), config.plugins.Boblight.scanb)) 
                                   
    def setTv(self):
    
        self.begin = config.plugins.Boblight.begincount.value
        self.floor = config.plugins.Boblight.floorstand.value
        self.seqq  = config.plugins.Boblight.clockwise.value
        self.leds_top = config.plugins.Boblight.lights_top.value
        self.leds_right = config.plugins.Boblight.lights_right.value
        self.leds_left = config.plugins.Boblight.lights_left.value
        self.leds_bottom = config.plugins.Boblight.lights_bottom.value
        self.leds_bottom_center = config.plugins.Boblight.lights_bottom_center.value
        
        if self.floor == str(2):
            self.leds_bottom_left = config.plugins.Boblight.lights_bottom_left.value
            self.leds_bottom_right = config.plugins.Boblight.lights_bottom_right.value
        elif self.floor == str(1):
            self.leds_bottom_left = 0
            self.leds_bottom_right = 0
                    
        self.total = self.leds_top + self.leds_right + self.leds_left + self.leds_bottom + self.leds_bottom_left + self.leds_bottom_right
        self.channels = (self.total)*3
        
        if self.begin == "left-bottom":
            if self.current != None:
                self.current.hide()
                self["pic_leftb"].show()
            self.current = self["pic_leftb"]
        elif self.begin == "left-top":
            if self.current != None:
                self.current.hide()
                self["pic_leftt"].show()
            self.current = self["pic_leftt"]
        elif self.begin == "top-right":
            if self.current != None:
                self.current.hide()
                self["pic_topr"].show()
            self.current = self["pic_topr"]
        elif self.begin == "top-left":
            if self.current != None:
                self.current.hide()
                self["pic_topl"].show()
            self.current = self["pic_topl"]
        elif self.begin == "right-top":
            if self.current != None:
                self.current.hide()
                self["pic_rightt"].show()
            self.current = self["pic_rightt"]
        elif self.begin == "right-bottom":
            if self.current != None:
                self.current.hide()
                self["pic_rightb"].show()
            self.current = self["pic_rightb"]
        elif self.begin == "bottom-left":
            if self.current != None:
                self.current.hide()
                self["pic_botl"].show()
            self.current = self["pic_botl"]
        elif self.begin == "bottom-right":
            if self.current != None:
                self.current.hide()
                self["pic_botr"].show()
            self.current = self["pic_botr"]
        elif self.begin == "bottom-middle":            
            if self.seqq == str(1):                
                if self.current != None:
                    self.current.hide()
                    self["pic_botmc"].show()
                self.current = self["pic_botmc"]
            elif self.seqq == str(2):                
                if self.current != None:
                    self.current.hide()
                    self["pic_botmb"].show()
                self.current = self["pic_botmb"]
        if self.floor == str(2):
            self["pic_floor"].show()
            self["pic_blocks_nof"].hide()
            self["pic_blocks_f"].show()       
        elif self.floor == str(1):
            self["pic_floor"].hide()  
            self["pic_blocks_f"].hide()
            self["pic_blocks_nof"].show()
        
        if self.seqq == str(1):
            seq = "clockwise"
        else:
            seq = "backwards"
        
        ErrorMsg = "Wrong direction: Can not start at %s because you going %s!" %(config.plugins.Boblight.begincount.getText(),seq)
        
        if self.check() == False:
            self["wrong"].setText(ErrorMsg)
            self["wrong"].setText("")
        elif self.check() == True:
            self["wrong"].setText("")
            
        self["leds-top"].setText(str(self.leds_top))        
        
        if self.floor == str(2):
            self["leds-bottom"].setText("")
            self["leds-bottom-left"].setText(str(self.leds_bottom_left))
            self["leds-bottom-right"].setText(str(self.leds_bottom_right))
        elif self.floor == str(1):
            self["leds-bottom"].setText(str(self.leds_bottom))
            self["leds-bottom-left"].setText("")
            self["leds-bottom-right"].setText("")
            
        self["leds-right"].setText(str(self.leds_right))
        self["leds-left"].setText(str(self.leds_left))
        self["channels"].setText("Leds: %s Channels %s" %(str(self.total),str(self.channels)))
                    
    def changedEntry(self):

        if self["config"].getCurrent()[1] == config.plugins.Boblight.type:
            if config.plugins.Boblight.type.value == "Oktolight":
                config.plugins.Boblight.rate.setValue(57600)
                config.plugins.Boblight.color.setValue("bgr")
                config.plugins.Boblight.output.setValue("/dev/ttyUSB0")             
            elif config.plugins.Boblight.type.value == "Karatelight":
                config.plugins.Boblight.rate.setValue(57600)
                config.plugins.Boblight.color.setValue("bgr")
                config.plugins.Boblight.output.setValue("/dev/ttyUSB0")
            elif config.plugins.Boblight.type.value == "Atmolight":
                config.plugins.Boblight.rate.setValue(38400)
                config.plugins.Boblight.color.setValue("rgb")
                config.plugins.Boblight.output.setValue("/dev/ttyUSB0")
            elif config.plugins.Boblight.type.value == "Adalight/Momo":
                config.plugins.Boblight.rate.setValue(115200)
                config.plugins.Boblight.color.setValue("rgb")
                config.plugins.Boblight.output.setValue("/dev/ttyUSB0")
            elif config.plugins.Boblight.type.value == "Sedulight 5A A0 A5":
                config.plugins.Boblight.rate.setValue(500000)
                config.plugins.Boblight.output.setValue("/dev/ttyUSB0")
            elif config.plugins.Boblight.type.value == "Sedulight 5A A1 A5":
                config.plugins.Boblight.rate.setValue(500000)
                config.plugins.Boblight.output.setValue("/dev/ttyUSB0")
            elif config.plugins.Boblight.type.value == "Sedulight 5A A2 A5":
                config.plugins.Boblight.rate.setValue(500000)
                config.plugins.Boblight.output.setValue("/dev/ttyUSB0")
            elif config.plugins.Boblight.type.value == "Sedulight 5A B0 A5":
                config.plugins.Boblight.rate.setValue(500000)
                config.plugins.Boblight.output.setValue("/dev/ttyUSB0")            		
            elif config.plugins.Boblight.type.value == "iBelight":
                config.plugins.Boblight.output.setValue("/dev/usb/hiddev0")
            elif config.plugins.Boblight.type.value == "Ambioder":
                config.plugins.Boblight.output.setValue("/dev/ttyUSB0")
        
        self.setTv()
        
        self.save()       
        self.createConfigList()
        self["config"].setList(self.list)
      
    def save(self):
        for x in self['config'].list:
            x[1].save()
        configfile.save() #save to file
        
    def keyOk(self):
        if self["config"].getCurrent()[1] == config.plugins.Boblight.output:
            self.session.openWithCallback(self.DeviceBrowserClosed, DeviceBrowser, currentDevice = config.plugins.Boblight.output.value)
	else:
	    self.save()
	    self.close()

    def keyGreen(self):
        self.save()
	self.createfile = True
	self.checkConfig()

    def keyBlue(self):
        self.session.open(BoblightAdjustScreen)
	
    def keyTest(self):
        #start check and set settings
        self.session.open(MessageBox, _("Test started...Red - Green - Blue\n"), MessageBox.TYPE_INFO, timeout = 10)
        container = eConsoleAppContainer()
        container.execute('killall -9 boblightd')
        sleep(1)
        m_bob.Control("test")

    def DeviceBrowserClosed(self, path):
        if path != False:
            config.plugins.Boblight.output.setValue(path)

    def checkConfig(self):
        seq = "backwards"
        if config.plugins.Boblight.clockwise.value == str(1):
            seq = "clockwise"
                        
        ErrorMsg = "Wrong direction: Can not start at %s because you going %s!" %(config.plugins.Boblight.begincount.getText(),seq)
        
        if config.plugins.Boblight.begincount.value == "bottom-left" and config.plugins.Boblight.clockwise.value == str(1):            
            self.session.open(MessageBox, _(ErrorMsg), MessageBox.TYPE_WARNING)  
        elif config.plugins.Boblight.begincount.value == "right-bottom" and config.plugins.Boblight.clockwise.value == str(1):            
            self.session.open(MessageBox, _(ErrorMsg), MessageBox.TYPE_WARNING)
        elif config.plugins.Boblight.begincount.value == "top-right" and config.plugins.Boblight.clockwise.value == str(1):            
            self.session.open(MessageBox, _(ErrorMsg), MessageBox.TYPE_WARNING)
        elif config.plugins.Boblight.begincount.value == "left-top" and config.plugins.Boblight.clockwise.value == str(1):            
            self.session.open(MessageBox, _(ErrorMsg), MessageBox.TYPE_WARNING)
        elif config.plugins.Boblight.begincount.value == "bottom-right" and config.plugins.Boblight.clockwise.value == str(2):            
            self.session.open(MessageBox, _(ErrorMsg), MessageBox.TYPE_WARNING)  
        elif config.plugins.Boblight.begincount.value == "right-top" and config.plugins.Boblight.clockwise.value == str(2):            
            self.session.open(MessageBox, _(ErrorMsg), MessageBox.TYPE_WARNING)
        elif config.plugins.Boblight.begincount.value == "top-left" and config.plugins.Boblight.clockwise.value == str(2):            
            self.session.open(MessageBox, _(ErrorMsg), MessageBox.TYPE_WARNING)
        elif config.plugins.Boblight.begincount.value == "left-bottom" and config.plugins.Boblight.clockwise.value == str(2):            
            self.session.open(MessageBox, _(ErrorMsg), MessageBox.TYPE_WARNING)
        else:
 
            self.BuiltConfig()
        
    def check(self):
        print"check()"
        ret = False
        if config.plugins.Boblight.begincount.value == "bottom-left" and config.plugins.Boblight.clockwise.value == str(1):            
            ret = False
        elif config.plugins.Boblight.begincount.value == "right-bottom" and config.plugins.Boblight.clockwise.value == str(1):            
            ret = False
        elif config.plugins.Boblight.begincount.value == "top-right" and config.plugins.Boblight.clockwise.value == str(1):            
            ret = False
        elif config.plugins.Boblight.begincount.value == "left-top" and config.plugins.Boblight.clockwise.value == str(1):            
            ret = False
        elif config.plugins.Boblight.begincount.value == "bottom-right" and config.plugins.Boblight.clockwise.value == str(2):            
            ret = False 
        elif config.plugins.Boblight.begincount.value == "right-top" and config.plugins.Boblight.clockwise.value == str(2):            
            ret = False
        elif config.plugins.Boblight.begincount.value == "top-left" and config.plugins.Boblight.clockwise.value == str(2):            
            ret = False
        elif config.plugins.Boblight.begincount.value == "left-bottom" and config.plugins.Boblight.clockwise.value == str(2):            
            ret = False
        else:
            ret = True
        
        return ret
               
    def BuiltConfig(self):

        print("[Boblight] BuiltConfig() ...")
        
	    #
	    # Set default values
	    #
        
        if self.createfile:
            precision       	= ""
	    serial		= ""
	    bus			= ""
	    address		= ""
            postfix         	= ""
            type            	= ""
            blacklevel      	= str(config.plugins.Boblight.blacklevel.value[0])+"."+str(config.plugins.Boblight.blacklevel.value[1])
            interval        	= "interval  	20000\n"
            delayafteropen  	= ""
            
        #
        # Set sections and depth
        #
        
        leds_bottom     = config.plugins.Boblight.lights_bottom.value
        leds_top        = config.plugins.Boblight.lights_top.value
        leds_left       = config.plugins.Boblight.lights_left.value
        leds_right      = config.plugins.Boblight.lights_right.value
        scanl           = config.plugins.Boblight.scanl.value
        scanr           = config.plugins.Boblight.scanr.value
        scant           = config.plugins.Boblight.scant.value
        scanb           = config.plugins.Boblight.scanb.value
        
        #
        # Bottom values, for tv's with floorstand.
        #
        
        leds_bottom_center = config.plugins.Boblight.lights_bottom_center.value
        leds_bottom_left   = config.plugins.Boblight.lights_bottom_left.value
        leds_bottom_right  = config.plugins.Boblight.lights_bottom_right.value
        leds_bottom_total  = (leds_bottom_left + leds_bottom_right + leds_bottom_center)
        
        #
        # Total channels
        #
        
        channels        = (leds_top + leds_left + leds_right + leds_bottom)*3

        #
        # Floorstand calculation
        #
        
        if config.plugins.Boblight.floorstand.value == str(2):
            print("[Boblight] Clockwise")
            print("[Boblight] Set floorstand to true")
            
            channels    = (leds_top + leds_left + leds_right + leds_bottom_total - leds_bottom_center)*3
            print("[Boblight] Channels: "+str(channels))
            
            # total step
            hScanStep    = 100 / leds_bottom_total;             # 100 / 20 lights = 5
            hScan_center = (hScanStep*leds_bottom_center)       # total center hscan // floorstand //  emptyplaces*hScanStep = ... 50
            hScan_right  = (hScanStep*leds_bottom_right)        # total right hscan /// light rights*hScanStep = ... 25
                
            hScanCurrent = 0 + (hScan_center - hScan_right);    # 25 
                
            hScanBottom_left  = hScanCurrent;                   # = 25 is plus
            hScanBottom_right = 100                             # = 25 + 50 = 75 is min
            
            # debug
            print("[Boblight] hScanBottom_left:"+str(hScanBottom_left)+" hScanBottom_right:"+str(hScanBottom_right))
                
            if config.plugins.Boblight.clockwise.value == str(2):   #backwards
                print("[Boblight] Backwards")
                print("[Boblight] Set floorstand to true")
            
                channels    = (leds_top + leds_left + leds_right + leds_bottom_total - leds_bottom_center)*3
                print("[Boblight] channels:"+str(channels))

                #total step
                hScanStep    = 100 / leds_bottom_total;                  # 100 / 20 lights = 5
                hScan_center = (hScanStep*leds_bottom_center)            # total center hscan // floorstand //  emptyplaces*hScanStep = ... 50
                hScan_left   = (hScanStep*leds_bottom_left)              # total left hscan /// light left*hScanStep = ... 25
                hScan_right  = (hScanStep*leds_bottom_right)
                
                hScanCurrent = (hScan_center + hScan_left);         # 75
                    
                hScanBottom_left  = 0.0;                              # = 75
                hScanBottom_right = hScanCurrent;                   # = 75 + 50 = 25

                print("[Boblight] hScanBottom_left:"+str(hScanBottom_left)+" hScanBottom_right:"+str(hScanBottom_right))
        
        elif config.plugins.Boblight.begincount.value == "bottom-right" or config.plugins.Boblight.begincount.value == "bottom-middle" or config.plugins.Boblight.begincount.value == "bottom-left":
            leds_bottom_right = leds_bottom/2;
            leds_bottom_left = leds_bottom/2;
                        
            if config.plugins.Boblight.clockwise.value == str(2):
                
                hScanStep    = 100 / leds_bottom;
                hScan_left   = (hScanStep*leds_bottom)              # total left hscan /// light left*hScanStep = ... 25
                hScan_right  = (hScanStep*leds_bottom)
                
                hScanCurrent = (hScan_left);         # 75
                    
                hScanBottom_left  = 0.0;                              # = 75
                hScanBottom_right = hScanCurrent;                   # = 75 + 50 = 25
            elif config.plugins.Boblight.clockwise.value == str(1):
                hScanStep    = 100 / leds_bottom;
                hScan_left   = (hScanStep*leds_bottom)              # total left hscan /// light left*hScanStep = ... 25
                hScan_right  = (hScanStep*leds_bottom)
                
                hScanCurrent = (hScan_right);         # 75
                    
                hScanBottom_left  = hScanCurrent;                              # = 75
                hScanBottom_right = 100.0;                   # = 75 + 50 = 25
        #
        # Atmolight need 4 channels more.
        #
        
        if config.plugins.Boblight.type.value == "Atmolight":
            channels += 4
                          
        total_lights = channels / 3;
        
        if self.createfile:
            #
            # Set some vars
            #
            
            if config.plugins.Boblight.color.value == "rgb":
                colorr = "FF0000"
                colorg = "00FF00"
                colorb = "0000FF"
            if config.plugins.Boblight.color.value == "gbr":
                colorr = "00FF00"
                colorg = "0000FF"
                colorb = "FF0000"
            
            #
            # Set prefix, type and interval
            #
            
            if config.plugins.Boblight.type.value == "Lightpack1":
                type    = "lightpack\n"
                interval= "interval  	20000\n"
                prefix  = "\n"
                bus	    = "bus		    "+str(config.plugins.Boblight.bus.value)+"\n"
                address = "address		"+str(config.plugins.Boblight.laddress.value)+"\n"
	    if config.plugins.Boblight.type.value == "Lightpack2":
                type    = "lightpack\n"
                interval= "interval  	20000\n"
                prefix  = "\n"
                serial	= "serial		"+config.plugins.Boblight.serial.value+"\n"
            if config.plugins.Boblight.type.value == "Oktolight":
                type    = "karate\n"
                interval= "interval  	16000\n"
                prefix  = "\n"
            if config.plugins.Boblight.type.value == "Karatelight":
                type    = "karate\n"
                interval= "interval  	16000\n"
                prefix  = "\n"
            if config.plugins.Boblight.type.value == "Atmolight":
                type    = "atmo\n"
                prefix  = "prefix    	FF\n"
                interval= "interval  	16000\n"
                prefix  = "\n"
            if config.plugins.Boblight.type.value == "Ambioder":
                type    = "ambioder\n"
                precision   = "255\n"
                interval= "interval  	20000\n"
                interval= "rate  	19200\n"
                delayafteropen = "delayafteropen  1000000\n"
                prefix  = "\n"
                channels = "3"
            if config.plugins.Boblight.type.value == "Adalight/Momo":
                type    = "momo\n"
                interval= "interval  	20000\n"
                delayafteropen = "delayafteropen  1000000\n"
                prefix  = "\n"	    
		            #
                # Prefix calculation [This only works for arduino boards]
                #
                
                os.system("/home/boblight-addons/prefix "+str(total_lights)+" > /tmp/prefix.txt")
		
                fo = open("/tmp/prefix.txt", "r")
                reading = fo.read(1000)
                fo.close()
                
                # remove tmpfile
                os.system("rm /tmp/prefix.txt")
		
                reading = reading.split("LEDS:  ")
                prefix = "prefix    	"+str(reading[1]);	
                print("[Boblight] Reading prefixfile for "+str(total_lights)+" leds: "+prefix)
            
            if config.plugins.Boblight.type.value == "iBelight":
                type    = "ibelight\n"
                interval= "interval  	20000\n"
                prefix  = "\n"
            if config.plugins.Boblight.type.value == "Sedulight 5A A0 A5":
            	prefix  = "prefix    	5A A0\n"
                postfix = "postfix    	A5\n"
                type    = "momo\n"
                interval= "interval    	10000\n"
                delayafteropen = "delayafteropen  1000000\n"
            if config.plugins.Boblight.type.value == "Sedulight 5A A1 A5":
                prefix  = "prefix    	5A A1\n"
                postfix = "postfix    	A5\n"
                type    = "momo\n"
                interval= "interval    	10000\n"
                delayafteropen = "delayafteropen  1000000\n"
            if config.plugins.Boblight.type.value == "Sedulight 5A A2 A5":
                prefix  = "prefix    	5A A2\n"
                postfix = "postfix    	A5\n"
                type    = "momo\n"
                interval= "interval    	10000\n"
                delayafteropen = "delayafteropen  1000000\n"
            if config.plugins.Boblight.type.value == "Sedulight 5A B0 A5":
                prefix  = "prefix    	5A B0\n"
                postfix = "postfix    	A5\n"
                type    = "momo\n"
                interval= "interval    	10000\n"
                delayafteropen = "delayafteropen  1000000\n"
                channels = "768"
            
            #
            # set the name            
            #
            
            name        = "ambilight"
	
	      #
        # Create file
        #
        
        if self.createfile:
            fo = open("/tmp/boblight.conf", "wb")
            fo.write("#[global]\n")
            fo.write("#interface	127.0.0.1\n")
            fo.write("#port		19333\n")
            fo.write("\n")
            
            fo.write("[device]\n")
            fo.write("name		"+name+"\n")
	    
	    if config.plugins.Boblight.type.value != "Lightpack1" and config.plugins.Boblight.type.value != "Lightpack2":
		fo.write("output    	"+config.plugins.Boblight.output.value+"\n")
            fo.write("type      	"+type)
	    fo.write("channels  	"+str(channels)+"\n")
            fo.write(interval)
	    fo.write(bus)
	    fo.write(address)
	    fo.write(serial)
            fo.write(precision)
            fo.write(prefix)
            fo.write(postfix)
            
            
            if config.plugins.Boblight.type.value != "iBelight" and config.plugins.Boblight.type.value != "Lightpack":
                fo.write("rate      	"+str(config.plugins.Boblight.rate.value)+"\n")
            
            fo.write("#debug     	off\n")
            fo.write(delayafteropen)
            fo.write("\n")
            
            fo.write("[color]\n")
            fo.write("name      	red\n")
            fo.write("rgb       	"+colorr+"\n")        
            fo.write("gamma         	"+str(config.plugins.Boblight.config_r_gamma.value[0])+"."+str(config.plugins.Boblight.config_r_gamma.value[1])+"\n")
            fo.write("adjust    	"+str(config.plugins.Boblight.config_r_adjust.value[0])+"."+str(config.plugins.Boblight.config_r_adjust.value[1])+"\n")
            fo.write("blacklevel	"+str(config.plugins.Boblight.config_r_blacklevel.value[0])+"."+str(config.plugins.Boblight.config_r_blacklevel.value[1])+"\n")
            fo.write("\n")
            
            fo.write("[color]\n")
            fo.write("name      	green\n")
            fo.write("rgb       	"+colorg+"\n")
            fo.write("gamma         	"+str(config.plugins.Boblight.config_g_gamma.value[0])+"."+str(config.plugins.Boblight.config_g_gamma.value[1])+"\n")
            fo.write("adjust    	"+str(config.plugins.Boblight.config_g_adjust.value[0])+"."+str(config.plugins.Boblight.config_g_adjust.value[1])+"\n")
            fo.write("blacklevel	"+str(config.plugins.Boblight.config_g_blacklevel.value[0])+"."+str(config.plugins.Boblight.config_b_blacklevel.value[1])+"\n")
            fo.write("\n")
            
            fo.write("[color]\n")
            fo.write("name          blue\n")
            fo.write("rgb       	"+colorb+"\n")
            fo.write("gamma         	"+str(config.plugins.Boblight.config_b_gamma.value[0])+"."+str(config.plugins.Boblight.config_b_gamma.value[1])+"\n")
            fo.write("adjust    	"+str(config.plugins.Boblight.config_b_adjust.value[0])+"."+str(config.plugins.Boblight.config_b_adjust.value[1])+"\n")
            fo.write("blacklevel	"+str(config.plugins.Boblight.config_b_blacklevel.value[0])+"."+str(config.plugins.Boblight.config_b_blacklevel.value[1])+"\n")
            fo.write("\n")
        
        #
        # begin to create lights section
        #
        
        if config.plugins.Boblight.type.value == "Ambioder":                    
            fo.write("[light]\n")
            fo.write("name            AM1\n")
            fo.write("color           red     "+name+" 1\n")
            fo.write("color           green   "+name+" 2\n")
            fo.write("color           blue    "+name+" 3\n")
            fo.write("hscan           0 100\n")
            fo.write("vscan           0 100\n")
        else:
            # Set lightCount to 1
            lightCount   = 1
            channelCount = 1
            
            # Atmolight need to start @ 4
            if config.plugins.Boblight.type.value == "Atmolight":
                channelCount = 4
            
            # Set v and h to 0
            vScanCurrent = 0
            hScanCurrent = 0
            
            #
            # Set the section sequence
            #
            
            if config.plugins.Boblight.begincount.value == "left-bottom" or config.plugins.Boblight.begincount.value == "left-top":
                if config.plugins.Boblight.clockwise.value == str(1):
                    sequence = "left,top,right,bottom" # Clockwise
                else:
                    sequence = "left,bottom,right,top" # Backwards
                    
                if config.plugins.Boblight.floorstand.value == str(2):
                    if config.plugins.Boblight.clockwise.value == str(1):
                        sequence = "left,top,right,bottom-right,bottom-center,bottom-left" # Clockwise
                    else:
                        sequence = "left,bottom-left,bottom-center,bottom-right,right,top" # Backwards
            
            if config.plugins.Boblight.begincount.value == "top-left" or config.plugins.Boblight.begincount.value == "top-right":
                if config.plugins.Boblight.clockwise.value == str(1):
                    sequence = "top,right,bottom,left" # Clockwise
                else:
                    sequence = "top,left,bottom,right" # Backwards
                    
                if config.plugins.Boblight.floorstand.value == str(2):
                    if config.plugins.Boblight.clockwise.value == str(1):
                        sequence = "top,right,bottom-right,bottom-center,bottom-left,left" # Clockwise
                    else:
                        sequence = "top,left,bottom-left,bottom-center,bottom-right,right" # Backwards
             
            if config.plugins.Boblight.begincount.value == "right-top" or config.plugins.Boblight.begincount.value == "right-bottom":
                if config.plugins.Boblight.clockwise.value == str(1):
                    sequence = "right,bottom,left,top" # Clockwise
                else:
                    sequence = "right,top,left,bottom" # Backwards
                
                if config.plugins.Boblight.floorstand.value == str(2):
                    if config.plugins.Boblight.clockwise.value == str(1):
                        sequence = "right,bottom-right,bottom-center,bottom-left,left,top" # Clockwise
                    else:
                        sequence = "right,top,left,bottom-left,bottom-center,bottom-right" # Backwards
             
            if config.plugins.Boblight.begincount.value == "bottom-right" or config.plugins.Boblight.begincount.value == "bottom-middle" or config.plugins.Boblight.begincount.value == "bottom-left":
                
                if config.plugins.Boblight.begincount.value == "bottom-middle":
                    if config.plugins.Boblight.clockwise.value == str(1):
                        sequence = "bottom-left,left,top,right,bottom-right" # Clockwise
                    else:
                        sequence = "bottom-right,right,top,left,bottom-left" # Backwards
                else:
                    if config.plugins.Boblight.clockwise.value == str(1):
                        sequence = "bottom,left,top,right" # Clockwise
                    else:
                        sequence = "bottom,right,top,left" # Backwards
                            
                if config.plugins.Boblight.floorstand.value == str(2):
                    if config.plugins.Boblight.clockwise.value == str(1):
                        sequence = "bottom-center,bottom-left,left,top,right,bottom-right" # Clockwise
                    else:
                        sequence = "bottom-center,bottom-right,right,top,left,bottom-left" # Backwards

            
            # Split the sequencearray       
            sequence = sequence.split(",")
            
	        # Debug
            print("[Boblight] sequence   = "+str(sequence))
            print("[Boblight] begincount = "+config.plugins.Boblight.begincount.value)

            # 100 0 100 0 0 100 0 100 clockwards
            # 0 100 100 0 100 0 0 100 backwards

            #
            # Sequence loop
            #
            
            totalCount = 1
            for section in sequence:

                if section == "left":
                    lights = leds_left
                    vScanCurrent = 100.00 # From LEFT-bottom to LEFT-top       # Clockwise
                    if config.plugins.Boblight.clockwise.value == str(2): 
                        vScanCurrent = 0.00 # From LEFT-top to LEFT-bottom     # Backwards
                    
                if section == "top":
                    lights = leds_top
                    hScanCurrent = 0.00 # From TOP-left to TOP-right           # Clockwise
                    if config.plugins.Boblight.clockwise.value == str(2): 
                        hScanCurrent = 100.00 # From TOP-right to TOP-left     # Backwards

                if section == "right":
                    lights = leds_right
                    vScanCurrent = 0.00 # From RIGHT-top to RIGHT-bottom       # Clockwise
                    if config.plugins.Boblight.clockwise.value == str(2): 
                        vScanCurrent = 100.00 # From RIGHT-bottom to RIGHT-top # Backwards

                if section == "bottom":
                    lights = leds_bottom
                    hScanCurrent = 100.00 # From BOTTOM-right to BOTTOM-left   # Clockwise
                    if config.plugins.Boblight.clockwise.value == str(2): 
                        hScanCurrent = 0.00 # From BOTTOM-left to BOTTOM-right # Backwards
                
                if section == "bottom-right":
                    lights = leds_bottom_right
                    hScanCurrent = float(hScanBottom_right)
                    if config.plugins.Boblight.clockwise.value == str(2): 
                        hScanCurrent = float(hScanBottom_right)
                        
                if section == "bottom-left":
                    lights = leds_bottom_left
                    hScanCurrent = float(hScanBottom_left)
                    if config.plugins.Boblight.clockwise.value == str(2): 
                        hScanCurrent = float(hScanBottom_left)
                
                '''###################  Bottom Center  ####################'''
                   
                
                if section == "bottom" and config.plugins.Boblight.begincount.value == "bottom-middle":
                    lights = leds_bottom
                    lights = lights/2; # we start at middle so we need to deceide it.
                    hScanCurrent = 50
                    
                if section == "bottom-left" and config.plugins.Boblight.begincount.value == "bottom-middle":
                    lights = leds_bottom_left
                    hScanCurrent = hScanBottom_left 
                    
                if section == "bottom-right" and config.plugins.Boblight.begincount.value == "bottom-middle":
                    lights = leds_bottom_right
                    hScanCurrent = hScanBottom_right 
                    
                '''########################################################'''
		
		        #
		        # Set start value
		        #
		
                if section == "left" and config.plugins.Boblight.begincount.value   == "left-bottom":
                    vScanCurrent = 100.00  # Start @ LEFT-bottom
                            
                if section == "left" and config.plugins.Boblight.begincount.value   == "left-top":
                    vScanCurrent = 0.00    # Start @ LEFT-top

                if section == "top" and config.plugins.Boblight.begincount.value    == "top-left":
                    hScanCurrent = 0.00    # Start @ TOP-left
                            
                if section == "top" and config.plugins.Boblight.begincount.value    == "top-right":
                    hScanCurrent = 100.00  # Start @ TOP-right
                            
                if section == "right" and config.plugins.Boblight.begincount.value  == "right-bottom":
                    vScanCurrent = 100.00  # Start @ RIGHT-bottom
                            
                if section == "right" and config.plugins.Boblight.begincount.value  == "right-top":
                    vScanCurrent = 0.00    # Start @ RIGHT-top
                        
                if section == "bottom" and config.plugins.Boblight.begincount.value == "bottom-left":
                    hScanCurrent = 0.00    # Start @ BOTTOM-left
                            
                if section == "bottom" and config.plugins.Boblight.begincount.value == "bottom-right":
                    hScanCurrent = 100.00  # Start @ BOTTOM-right
                
                
                lightCount = 1 #lights counter
                
                # Atmolight need to start @ 4
                if config.plugins.Boblight.type.value == "Atmolight":
                    lightCount = 4
                
                # Empty places for floorstand option
                if section == "bottom-center":
                    lights = 0; #Set lights to 0, we want not into loop.
		
		        # Debug
                #print("[Boblight] Overlap               :  "+str(overlap))
                print("[Boblight] Start section         :  "+str(section))
                print("[Boblight] Start lights          :  "+str(lights))
                print("[Boblight] Start HscanCurrent    :  "+str(hScanCurrent))
                print("[Boblight] Start VscanCurrent    :  "+str(vScanCurrent))
                
                #
                # check if section contains more then 0 lights
                #
                
                if lights > 0:
                    
                    # Steps
                    vScanStep  = 100.00 / lights;
                    hScanStep  = 100.00 / lights;
                    
                    # Debug
                    print("[Boblight] vScanStep  100/"+str(lights)+" :  "+str(vScanStep))
                    print("[Boblight] hScanStep  100/"+str(lights)+" :  "+str(hScanStep))
                	
                    # Set other step for floorstand option
                    if config.plugins.Boblight.floorstand.value == str(2):
                        if section == "bottom-left" or section == "bottom-right" or section == "bottom-center":
                            hScanStep  = 100.00 / leds_bottom_total; 
                    elif config.plugins.Boblight.begincount.value == "bottom-middle":                    
                        if section == "bottom-left" or section == "bottom-right":
                            hScanStep  = 100.00 / leds_bottom; 
                            
                    # Loop
                    while(lightCount <= lights):
                        
                        if section == "right" or section == "top":
                            vScanEnd     = vScanCurrent
                            hScanEnd     = hScanCurrent
                            
                            if config.plugins.Boblight.clockwise.value == str(2): #backwards
                                vScanStart   = vScanCurrent - vScanStep
                                hScanStart   = hScanCurrent - hScanStep
                            else:
                                vScanStart   = vScanCurrent + vScanStep
                                hScanStart   = hScanCurrent + hScanStep
                            
                            vScanCurrent = vScanStart
                            hScanCurrent = hScanStart

                        if section == "left" or section == "bottom" or section == "bottom-left" or section == "bottom-right":
                            vScanStart   = vScanCurrent
                            hScanStart   = hScanCurrent
                            
                            if config.plugins.Boblight.clockwise.value == str(2): #backwards
                                vScanEnd     = vScanCurrent + vScanStep
                                hScanEnd     = hScanCurrent + hScanStep
                                if section == "bottom-right" and config.plugins.Boblight.begincount.value == "bottom-middle":
                                    hScanEnd     = hScanCurrent - hScanStep
                            else:
                                vScanEnd     = vScanCurrent - vScanStep
                                hScanEnd     = hScanCurrent - hScanStep
                            
                            vScanCurrent = vScanEnd
                            hScanCurrent = hScanEnd
                        
                        if self.createfile:
                            fo.write("\n")
                            fo.write("\n")
                        
                        
                        # Light name must be 3 chars in new releases from R9
                        s = str(totalCount)
                        s += "XX"
                        
                        length  = len(s)
                        mini    = length -3
                        
                        if length is 4 or length > 4:
                            s = s[:-mini]                                        
                        
                        if self.createfile:
                            fo.write("[light] #"+section+"\n")
                            fo.write("name          "+str(s)+"\n")

                            fo.write("color         red     "+name+" "+str(channelCount)+"\n")
                            channelCount += 1;

                            fo.write("color         green   "+name+" "+str(channelCount)+"\n")
                            channelCount += 1;

                            fo.write("color         blue    "+name+" "+str(channelCount)+"\n")
                            channelCount += 1;
                        
                        # Swap end and start if it's clockwise
                        if config.plugins.Boblight.clockwise.value == str(1):
                            v = vScanEnd;vScanEnd = vScanStart;vScanStart = v;
                            h = hScanEnd;hScanEnd = hScanStart;hScanStart = h;

                        # Set hscan and vscan
                        if section == "right":
                            vs = abs(round(vScanStart,2))
                            ve = abs(round(vScanEnd,2))
                            hd = 100.00 - scanr
                            if self.createfile:
                                fo.write("hscan         "+str(hd)+" 100 \n")
                                fo.write("vscan         "+str(vs)+" "+str(ve)+"\n")
                            
                            #step = i * (300 / config.plugins.Boblight.lights_right.value)
                            #self.c.fill(390, vs*2, 5, 5, RGB(000,000,255))
                            #print "step-right %s" %(str(vs*2))    
                    
                		    # Debug
                            print("[Boblight] vScanStart  :  "+str(vs))
                            print("[Boblight] vScanEnd    :  "+str(ve))
                		
                        if section == "bottom" or section == "bottom-left" or section == "bottom-right":
                            hs = abs(round(hScanStart,2))
                            he = abs(round(hScanEnd,2))
                            vd = 100.00 - scanb
                            
                            if self.createfile:
                                fo.write("hscan         "+str(hs)+" "+str(he)+"\n")
                                fo.write("vscan         "+str(vd)+" 100\n")
                            
                		    # Debug
                            print("[Boblight] hScanStart  :  "+str(hs))
                            print("[Boblight] hScanEnd    :  "+str(he))

                        if section == "top":
                            hs = abs(round(hScanStart,2))
                            he = abs(round(hScanEnd,2))       
                            vd = scant
                            
                            if self.createfile:
                                fo.write("hscan         "+str(hs)+" "+str(he)+"\n")
                                fo.write("vscan         0 "+str(vd)+"\n")
                            
                            #self.c.fill(hs*4, 0, 5, 5, RGB(255,000,000))
                            #print "step-top %s" %(str(hs*4))
                            
                		    # Debug
                            print("[Boblight] hScanStart  :  "+str(hs))
                            print("[Boblight] hScanEnd    :  "+str(he))
                		
                        if section == "left":
                            vs = abs(round(vScanStart,2))
                            ve = abs(round(vScanEnd,2))
                            hd = scanl
                            
                            if self.createfile:
                                fo.write("hscan         0 "+str(hd)+"\n")
                                fo.write("vscan         "+str(vs)+" "+str(ve)+"\n")
                            
                            #self.c.fill(0, vs*2, 5, 5, RGB(000,255,000))
                            #print "step-left %s" %(str(vs*2))
                            
                		    # Debug
                            print("[Boblight] vScanStart  :  "+str(vs))
                            print("[Boblight] vScanEnd    :  "+str(ve))
                            
                        lightCount  += 1; # Counter for sections
                        totalCount  += 1;
                   
                    # End loop
            
            #self.c.flush()
        
        if self.createfile:
            fo.close();
            fil = os.path.isfile("/etc/boblight.conf")
            if fil == True:
                Msg = "boblight.conf created in /tmp.\nit's already in /etc, overwrite ?"
                self.session.openWithCallback(self.MoveToEtc, MessageBox, _(Msg), MessageBox.TYPE_YESNO)
                self.session.open(MessageBox, _("/etc/boblight.conf created succesfull!"), MessageBox.TYPE_INFO, timeout=4) 
            else:
                os.system("mv /tmp/boblight.conf /etc/boblight.conf")
                self.session.open(MessageBox, _("/etc/boblight.conf created succesfull!"), MessageBox.TYPE_INFO, timeout=4)
        self.createfile = False                
        
    def MoveToEtc(self, answer):
        if answer is True:
            #os.system("stty -F "+config.plugins.Boblight.output.value+" "+str(config.plugins.Boblight.rate.value)) # set speed for serialport
            os.system("mv /tmp/boblight.conf /etc/boblight.conf") # Copy file to /etc


#########################################
#
#   About screen
#    
#########################################

class BoblightAboutScreen(Screen, ConfigListScreen):

    skin = """
        <screen name="BoblightAboutScreen" position="%d,%d" size="550,250" title="%s" >
            <widget name="pluginInfo"	position="5,5"   size="550,240" valign="center" halign="left"  zPosition="5" transparent="1" foregroundColor="white" font="Regular;14"/>       
		</screen>""" % (
            (DESKTOP_WIDTH - 550) / 2, (DESKTOP_HEIGHT - 250) / 2,
            _("About Boblight"),)

    def __init__(self,session):
        self.session = session
        Screen.__init__(self, session)
        
        self["aboutActions"] = ActionMap(["BoblightActions"],
            {
            	"cancel": self.exit,
            	"ok": self.exit
            }, -2)
        
        self.info ="Boblight for Enigma2 (v" + config.plugins.Boblight.version.value + ") (c) 2013 by \nSpeedy1985 And Oktay Oeztueter <http://wp.oktay.com/> (Creator of Oktolight)\n"
        self.info +="\n"
        self.info +="Deamon (v2.0) (c) 2009 by Bob Loosen.\n\n"
        self.info +="Thanks to: Nietgiftig, Stephan, Meega and Holymoly.\n\n"
        self.info +="Translations: German - Holymoly.\n"
        self.info +="For more info: www.boblightenigma2.net"
        self["pluginInfo"] = Label(self.info)
    
    def exit(self):
        self.close()
        
#########################################
#
#   Network settings
#    
#########################################
        
class NetworkSettingsScreen(Screen, ConfigListScreen):

    skin = """
        <screen name="NetworkSettingsScreen" position="%d,%d" size="700,170" title="%s" >	
        <widget name="config" position="10,5" size="690,140" zPosition="5" transparent="1" foregroundColor="white"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_green.png" zPosition="2"  position="10,142" size="35,29" alphatest="on" />        
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_yellow.png" zPosition="2"  position="220,142" size="35,29" alphatest="on" />
        <widget name="buttongreen" position="60,146" size="150,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
        <widget name="buttonyellow" position="270,146" size="350,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
		</screen>""" % (
            (DESKTOP_WIDTH - 700) / 2, (DESKTOP_HEIGHT - 170) / 2,_("Network Settings"),)

    def __init__(self,session):
        self.session = session
        Screen.__init__(self, session)
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
        self["buttongreen"] = Label(_("Save"))
        self["buttonyellow"] = Label(_("Restart client"))
        self["networkActions"] = ActionMap(["BoblightActions"],
            {
            	"cancel":	self.keyExit,
            	"ok": 		self.keyOk,
            	"yellow": 	self.keyYellow,
            	"green":	self.keyOk
            }, -2)
	    
        self.actualSession = self.session
        self.status()
	    
    def createConfigList(self):
        self.list = []  
        self.list.append(getConfigListEntry(_('Enable network mode (only client will be started):'), config.plugins.Boblight.network_onoff))

        #Ip address
        if config.plugins.Boblight.network_onoff.value is True: 
            self.list.append(getConfigListEntry(_('Daemon Ip address:'), config.plugins.Boblight.address))
            self.list.append(getConfigListEntry(_('Daemon Port:'), config.plugins.Boblight.port))
        
        self.list.append(getConfigListEntry(_('Use BoblightRemote (Android app, (not ready for now)):'), config.plugins.Boblight.android))
        if config.plugins.Boblight.android.value is True:
            self.list.append(getConfigListEntry(_('Port for BoblightRemote:'), config.plugins.Boblight.android_port))
                       
    def changedEntry(self):                 
        self.createConfigList()
        self["config"].setList(self.list)        
        
    
    def getCurrentSelection(self):
        return self["config"].getCurrent()[1]
        
    def save(self):
        for x in self['config'].list:
            x[1].save()
        self.changedEntry() #Refresh list
        configfile.save() #save to file
    
    def keyYellow(self):
        self.save()
        m_bob.checkNetwork()
        m_bob.Restart(self.session)

    def keyOk(self):
        self.save()

        self.status()
        self.close()
            
    def status(self):
        m_bob.getStatus()
       
    def keyExit(self):
        self.save()
        self.status()             
        self.close()

#########################################
#
#   Color Adjustment
#    
#########################################
        
class AdjustmentScreen(Screen, ConfigListScreen):

    skin = """
        <screen name="AdjustmentScreen" position="%d,%d" size="600,350" title="%s" >	
        <widget name="config" position="10,5" size="580,200" zPosition="5" transparent="1" foregroundColor="white"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_green.png" zPosition="2"  position="10,218" size="35,29" alphatest="on" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_left.png" zPosition="2"  position="210,218" size="35,29" alphatest="on" />
	<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_right.png" zPosition="2"  position="410,218" size="35,29" alphatest="on" />        
        <widget name="buttongreen" position="60,220" size="150,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
	<widget name="buttonleft" position="260,220" size="150,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
	<widget name="buttonright" position="460,220" size="150,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
        <widget name="infoLabel" position="10,220" size="590,40" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>
		</screen>""" % (
            (DESKTOP_WIDTH - 600) / 2, (DESKTOP_HEIGHT - 200) / 2,_("Live RGB Adjustment Settings"),)

    def __init__(self,session):
        self.session = session
        self.selected = None
        Screen.__init__(self, session)
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
	
	### TEST ###
	self.aspect = getAspect()
	self.old_service = self.session.nav.getCurrentlyPlayingServiceReference()	
	
	# Disable OSD Transparency
	try:
	    self.can_osd_alpha = open("/proc/stb/video/alpha", "r") and True or False
	except:
	    self.can_osd_alpha = False
	
	if config.plugins.Boblight.sampleBackground.getValue() == True:
	    self.showBackground()
	
        self["buttongreen"] = Label(_("Save"))
	self["buttonleft"] = Label(_("Jump 10 backward"))
	self["buttonright"] = Label(_("Jump 10 forward"))  
        self["networkActions"] = ActionMap(["BoblightActions"],
            {
            	"cancel":	self.keyExit,
            	"ok": 		self.keyExit,
            	"green":	self.keyExit,
		"jumpNextMark":	self.keyNext,
		"jumpPreviousMark": self.keyPrev
            }, -2)
    
    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(_('Use live Adjust Settings:'), config.plugins.Boblight.use_live_adjust))
	self.list.append(getConfigListEntry(_('Color sequence:'), config.plugins.Boblight.color))
	if config.plugins.Boblight.use_live_adjust.value is True:
	    if config.plugins.Boblight.color.value == "rgb":
		self.list.append(getConfigListEntry(_('Adjust RED   %s   ')% str(config.plugins.Boblight.adjustr.getValue()), config.plugins.Boblight.adjustr))
		self.list.append(getConfigListEntry(_('Adjust GREEN %s   ')% str(config.plugins.Boblight.adjustg.getValue()), config.plugins.Boblight.adjustg))
		self.list.append(getConfigListEntry(_('Adjust BLUE  %s   ')% str(config.plugins.Boblight.adjustb.getValue()), config.plugins.Boblight.adjustb))
	    elif config.plugins.Boblight.color.value == "bgr":
		self.list.append(getConfigListEntry(_('Adjust BLUE  %s   ')% str(config.plugins.Boblight.adjustr.getValue()), config.plugins.Boblight.adjustr))
		self.list.append(getConfigListEntry(_('Adjust GREEN %s   ')% str(config.plugins.Boblight.adjustg.getValue()), config.plugins.Boblight.adjustg))
		self.list.append(getConfigListEntry(_('Adjust RED   %s   ')% str(config.plugins.Boblight.adjustb.getValue()), config.plugins.Boblight.adjustb))
				
	self.list.append(getConfigListEntry(_('Show background test picture:'), config.plugins.Boblight.sampleBackground))
	if config.plugins.Boblight.sampleBackground.getValue() == True:
	    self.list.append(getConfigListEntry(_('Test picture:'), config.plugins.Boblight.sampleBackground_mvi))
	    
    def changedEntry(self):                 
        self.createConfigList()
        self["config"].setList(self.list)                
        
        self.selected = self["config"].getCurrent()[1]
        
	if self.selected is config.plugins.Boblight.sampleBackground or self.selected is config.plugins.Boblight.sampleBackground_mvi:
	    if config.plugins.Boblight.sampleBackground.getValue() is True:
		self.showBackground()
	    else:
		self.showOldService()
		    
	th = threading.Thread(target=m_bob.changeValue(self.selected), args=[])
	th.start()
	
    def showOldService(self):
	# Restart old service
	self.session.nav.stopService()
	self.session.nav.playService(self.old_service)
	
	## Restore OSD Transparency Settings
	os.system("echo " + hex(0)[2:] + " > /proc/stb/vmpeg/0/dst_top")
	os.system("echo " + hex(0)[2:] + " > /proc/stb/vmpeg/0/dst_left")
	os.system("echo " + hex(720)[2:] + " > /proc/stb/vmpeg/0/dst_width")
	os.system("echo " + hex(576)[2:] + " > /proc/stb/vmpeg/0/dst_height")

	if self.can_osd_alpha:
	    try:
		open("/proc/stb/video/alpha", "w").write(str(config.av.osd_alpha.value))
	    except:
		print "Set OSD Transparacy failed"
    
    def showBackground(self):
	### TEST ###	
	self.session.nav.stopService()

	# Disable OSD Transparency
	try:
	    self.can_osd_alpha = open("/proc/stb/video/alpha", "r") and True or False
	except:
	    self.can_osd_alpha = False
	
	if self.can_osd_alpha:
	    open("/proc/stb/video/alpha", "w").write(str("255"))
	
	# Show Background MVI
	os.system("/usr/bin/showiframe /usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/mvi/"+str(config.plugins.Boblight.sampleBackground_mvi.getValue())+".mvi &")
		
	### END TEST ###
    
    def save(self):
        for x in self['config'].list:
            x[1].save()
        self.changedEntry() #Refresh list
        configfile.save() #save to file
    
    def keyNext(self):
	print "keyNext"
	self.selected = self["config"].getCurrent()[1] 
	if self.selected == config.plugins.Boblight.adjustr:
	    config.plugins.Boblight.adjustr.setValue(Clamp(config.plugins.Boblight.adjustr.getValue()+10,0,255))
	elif self.selected == config.plugins.Boblight.adjustg:
	    config.plugins.Boblight.adjustg.setValue(Clamp(config.plugins.Boblight.adjustg.getValue()+10,0,255))
	elif self.selected == config.plugins.Boblight.adjustb:
	    config.plugins.Boblight.adjustb.setValue(Clamp(config.plugins.Boblight.adjustb.getValue()+10,0,255))
	self.changedEntry() #Refresh list
	
    def keyPrev(self):
	print "keyPrev"
	self.selected = self["config"].getCurrent()[1]
	if self.selected == config.plugins.Boblight.adjustr:
	    config.plugins.Boblight.adjustr.setValue(Clamp(config.plugins.Boblight.adjustr.getValue()-10,0,255))
	elif self.selected == config.plugins.Boblight.adjustg:
	    config.plugins.Boblight.adjustg.setValue(Clamp(config.plugins.Boblight.adjustg.getValue()-10,0,255))
	elif self.selected == config.plugins.Boblight.adjustb:
	    config.plugins.Boblight.adjustb.setValue(Clamp(config.plugins.Boblight.adjustb.getValue()-10,0,255))
	self.changedEntry() #Refresh list    

    def keyExit(self):
        self.save()
	if config.plugins.Boblight.sampleBackground.getValue() is True:
	    self.showOldService()
        self.close()
                
#########################################
#
#    Timer settings
#    
#########################################
        
class TimerSettingsScreen(Screen, ConfigListScreen):

    skin = """
        <screen name="TimerSettingsScreen" position="%d,%d" size="700,170" title="%s" >	
        <widget name="config" position="10,5" size="690,140" zPosition="5" transparent="1" foregroundColor="white"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_green.png" zPosition="2"  position="10,142" size="35,29" alphatest="on" />        
        <widget name="buttongreen" position="60,146" size="150,20" valign="center" halign="left" zPosition="2" foregroundColor="white" font="Regular;16"/>        
		</screen>""" % (
            (DESKTOP_WIDTH - 700) / 2, (DESKTOP_HEIGHT - 170) / 2,_("Timer Settings"),)

    def __init__(self,session):
        self.session = session
        Screen.__init__(self, session)
        self.createConfigList()
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
        self["buttongreen"] = Label(_("Save"))
        self["networkActions"] = ActionMap(["BoblightActions"],
            {
            	"cancel":	self.keyExit,
            	"ok": 		self.keyOk,
            	"green":	self.keyOk
            }, -2)

    def createConfigList(self):
        self.list = []  
        self.list.append(getConfigListEntry(_('Timer:'), config.plugins.Boblight.timer_onoff))

        if config.plugins.Boblight.timer_onoff.value is True:
            self.list.append(getConfigListEntry(_('Don\'t turn lights off/on in standby:'), config.plugins.Boblight.timer_standby_onoff))
            self.list.append(getConfigListEntry(_("Enable lights:"), config.plugins.Boblight.time_start))
            self.list.append(getConfigListEntry(_("Disable lights:"),   config.plugins.Boblight.time_end))
        '''
        self.list.append(getConfigListEntry(_('Change brightness at given time:'), config.plugins.Boblight.brightness_timer_onoff))
        if config.plugins.Boblight.timer_onoff.value is True: 
            self.list.append(getConfigListEntry(_("Change brightness at:"), config.plugins.Boblight.brightness_time_start))
            self.list.append(getConfigListEntry(_("Restore brightness at:"),   config.plugins.brightness_time_start))
            self.list.append(getConfigListEntry(_('Brightness: (%s)') % str(config.plugins.Boblight.value.getValue()), config.plugins.Boblight.value))
        '''
        
    def changedEntry(self):                 
        self.createConfigList()
        self["config"].setList(self.list)        

    def save(self):
        for x in self['config'].list:
            x[1].save()
        self.changedEntry() #Refresh list
        configfile.save() #save to file
    
    def keyOk(self):
        self.save()
        self.close()
       
    def keyExit(self):
        self.save()       
        self.close()


#########################################
#
#   Main
#    
#########################################
        
class BoblightConfig(Screen, ConfigListScreen):

    onChangedEntry = [ ]
    
    boblist = BOBLIST_MAIN
    
    boblist_main      = []
    boblist_color     = []
    boblist_moodlamp  = []
    
    isFinisched = False
	
    skin = """
    <screen position="%d,%d" size="1100,580" title="%s" >
    
    <widget name="config_title" position="10,10" size="780,40"  zPosition="4" font="Regular;22"/>
    <widget name="config_fps"   position="380,10" size="400,40" halign="right" zPosition="5" font="Regular;18"/>
    <widget name="config_information"   position="830,10" size="200,40" halign="left" zPosition="2" font="Regular;22"/>
    
    <ePixmap pixmap="skin_default/div-h.png" position="10,50" size="780,2" zPosition="4" transparent="1" alphatest="on"/>     
    <ePixmap pixmap="skin_default/div-v.png" position="810,50" size="2,350" zPosition="4" transparent="1" alphatest="on"/>      
    <ePixmap pixmap="skin_default/div-h.png" position="830,50" size="260,2" zPosition="4" transparent="1" alphatest="on"/>   
    <ePixmap pixmap="skin_default/div-h.png" position="830,410" size="260,2" zPosition="4" transparent="1" alphatest="on"/> 
	    
    <widget name="config"       position="10,60" size="780,390" zPosition="1" scrollbarMode="showOnDemand"/>
    <widget name="config_information_text"   position="830,60" size="260,350" halign="left" zPosition="2" font="Regular;14"/>    

    <ePixmap pixmap="skin_default/div-h.png" position="10,410" size="780,2" zPosition="4" transparent="1" alphatest="on"/>    
    <ePixmap name="logo" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/logo.png" zPosition="2" position="10,430" size="150,150" alphatest="on" />
    
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_1.png" zPosition="5" position="365,430" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_2.png" zPosition="5" position="365,460" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_3.png" zPosition="5" position="365,490" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_4.png" zPosition="5" position="365,520" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_5.png" zPosition="5" position="365,550" size="35,29" alphatest="on" />
    
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_6.png" zPosition="5" position="600,430" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_7.png" zPosition="5" position="600,460" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_8.png" zPosition="5" position="600,490" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_0.png" zPosition="5" position="600,520" size="35,29" alphatest="on" />
    
    <widget name="button1"      position="410,432" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>
    <widget name="button2"      position="410,462" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>
    <widget name="button3"      position="410,492" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>
    <widget name="button4"      position="410,522" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>		
    <widget name="button5"      position="410,552" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>	
    <widget name="button6"      position="645,432" size="100,20" valign="center" halign="left" zPosition="6" foregroundColor="white" font="Regular;16"/>		
    <widget name="button7"      position="645,462" size="130,20" valign="center" halign="left" zPosition="6" foregroundColor="white" font="Regular;16"/>
    <widget name="button8"      position="645,492" size="130,20" valign="center" halign="left" zPosition="6" foregroundColor="white" font="Regular;16"/>
    <widget name="button0"      position="645,522" size="100,20" valign="center" halign="left" zPosition="6" foregroundColor="red" font="Regular;16"/>				
       
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_green.png" zPosition="5" position="185,430" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_red.png" zPosition="5" position="185,460" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_yellow.png" zPosition="5" position="185,490" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_blue.png" zPosition="5" position="185,520" size="35,29" alphatest="on" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/pic/buttons/key_info.png" zPosition="5" position="185,550" size="35,29" alphatest="on" />
    
    <widget name="buttongreen"  position="230,432" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>
    <widget name="buttonred"    position="230,462" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>
    <widget name="buttonyellow" position="230,492" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>
    <widget name="buttonblue"   position="230,522" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>
    <widget name="buttoninfo"   position="230,552" size="180,20" valign="center" halign="left" zPosition="4" foregroundColor="white" font="Regular;16"/>
    
    <widget name="preview" position="830,432" size="200,20" valign="center" halign="left" zPosition="10" foregroundColor="white" font="Regular;16"/>        
    <widget source="Canvas" render="Canvas" position="830,462" zPosition="10" size="250,300" />
        
    </screen>""" % (
                (DESKTOP_WIDTH - 1100) / 2, (DESKTOP_HEIGHT - 580) / 2, # center position
                _("Boblight For Enigma2 - %s" % pluginversion))

    def __init__(self, session, args=0):
        Screen.__init__(self, session)

        # create config list
        self.createConfigLists()
        ConfigListScreen.__init__(self, [], session = self.session, on_change = self.changedEntry)

        #select
        self.selectConfigList()
        self.t = None
        self.UpdateCheckDone = False
	
	### TEST ###
	self.aspect = getAspect()
	#self.old_service = self.session.nav.getCurrentlyPlayingServiceReference()	
	
	#print "[Boblight] Save Old Service: %s" %(str(self.old_service))
	
	# Disable OSD Transparency
	try:
	    self.can_osd_alpha = open("/proc/stb/video/alpha", "r") and True or False
	except:
	    self.can_osd_alpha = False
	
	
        self["button1"] = Label(_("Mainmenu"))
        self["button2"] = Label(_("Color tuning"))
        self["button3"] = Label(_("Moodlamp settings"))
        self["button4"] = Label(_("Network settings"))
        self["button5"] = Label(_("Config creator"))
        self["button6"] = Label(_("Timer"))
        self["button7"] = Label(_("Refresh fps"))
        self["button8"] = Label(_("Live RGB Adjust"))
        self["button0"] = Label(_("Force kill"))
        self["buttonred"] = Label(_("Lights off"))
        self["buttongreen"] = Label(_("Lights on"))
        self["buttonyellow"] = Label(_("Restart"))
        self["buttonblue"] = Label(_("Default"))
        self["buttoninfo"] = Label(_("About"))
        
        self["Canvas"] = CanvasSource() 
        self["preview"] = Label(_("Moodlamp color:"))
        self["config_fps"] = Label(".. fps")
        self["config_information"] = Label(_("Information"))
        self["config_title"] = Label("")
        self["config_information_text"] = Label(_(""))
        
        
        self["actions"] = ActionMap(["BoblightActions"],
            {	
            	"ok":	self.keyOk,
            	"cancel":	self.keyExit,
            	"red":		self.keyRed,
                "green":	self.keyGreen,
                "yellow":	self.keyYellow,
                "blue":		self.keyBlue,
                "info":		self.keyInfo,
                "key_1":	self.key1,
                "key_2":	self.key2,
                "key_3":	self.key3,
                "key_4":	self.key4,
                "key_5":	self.key5,
                "key_6":	self.key6,
                "key_8":	self.key8,
                "key_7":	self.setStatus,
                "key_0":	self.forceKill,
                "down":	    self.keyDown,
                "up":	    self.keyUp,
		        "jumpNextMark":	self.keyNext,
		        "jumpPreviousMark": self.keyPrev
            }, -2)
        
        self.isFinisched = True
        
        # update running status etc
        self.updateStatus()        
        
        #send all values to client        
        th = threading.Thread(target=m_bob.sendAll(), args=[])
        th.start()
        
        self.setStatus()
        self.setInfoText()        
        
        if config.plugins.Boblight.checkforupdate.value is True and config.plugins.Boblight.arch.value != "":
            self.onFirstExecBegin.append(self.checkForUpdate)
        
    def checkForUpdate(self):
        self.url = config.plugins.Boblight.url.value + config.plugins.Boblight.updatexml.value
        print("Checking URL: " + self.url) 
        try:
	        f = urllib2.urlopen(self.url)
	        html = f.read()
	        dom = parseString(html)
	        update = dom.getElementsByTagName("update")[0]
	        version = update.getElementsByTagName("version")[0]
	        remoteversion = version.childNodes[0].data
	        urls = update.getElementsByTagName("url")
	        currentversion = config.plugins.Boblight.version.value
	            
	        self.remoteurl = ""
	        for url in urls:
		        self.remoteurl = url.childNodes[0].data
	
	        self.remoteurl = self.remoteurl.replace("arch", config.plugins.Boblight.arch.value)
	        self.remoteurl = self.remoteurl.replace("\n", "")
	        #print("""Version: %s - URL: %s""" % (remoteversion, self.remoteurl))
        
	        if currentversion != remoteversion and self.remoteurl != "":
		    self.session.openWithCallback(self.startUpdate, MessageBox,_("""A new version of Boblight-E2 is available for download!\n\nVersion: %s""" % remoteversion), MessageBox.TYPE_YESNO)		    
        except Exception, e:
	        print """Could not download HTTP Page (%s)""" % e


    def startUpdate(self, answer):
	    if answer is True:
		    self.session.open(BoblightUpdate, self.remoteurl)
		
    def forceKill(self):
    	m_bob.Control("kill")
    	self.session.open(MessageBox, _("Force killing boblight..."), MessageBox.TYPE_INFO, timeout=2)
    	self.selectConfigList()
    	    
    def keyDown(self):
        #print "key down"
        self["config"].instance.moveSelection(self["config"].instance.moveDown)
        self.setInfoText()
		
    def keyUp(self):
        #print "key up"
        self["config"].instance.moveSelection(self["config"].instance.moveUp)
        self.setInfoText()

									
    def selectConfigList(self, element=None):
        try:
            self.isFinisched = False
            # remove old notifiers
            for x in self["config"].list:
	            x[1].setNotifiers(None)

            list = []

            if self.boblist == BOBLIST_MAIN:
                list = self.boblist_main
            elif self.boblist == BOBLIST_COLOR:
                list = self.boblist_color		
		    
            elif self.boblist == BOBLIST_MOODLAMP:
                list = self.boblist_moodlamp

            self["config"].list = list

            self.isFinisched = True
            
            self.setInfoText()
            
        except KeyError:
            print "[Boblight] selectConfigList: KeyError"
        
    def changedEntry(self):
        print "[Boblight] changedEntry in List: %s" %(str(BOBLIST_TITLES[self.boblist]))
        
        if self.boblist == BOBLIST_MAIN:
            self.updateMainConfig()
            
        elif self.boblist == BOBLIST_COLOR:
            
            if self["config"].getCurrent()[1] == config.plugins.Boblight.presets:
                self.getCustom(config.plugins.Boblight.presets.getValue());

            self.updateColorConfig()

        elif self.boblist == BOBLIST_MOODLAMP:
            self.updateMoodlampConfig()
            self.setBackground()
	
        #send actual setting to daemon
        self.sendValue()
        #self.checkForUpdate()
        
    def createConfigLists(self):
        self.updateColorConfig()
        self.updateMoodlampConfig()
        self.updateMainConfig()

    def sendSetting(self, element=None):
        self.selected = self["config"].getCurrent()[1]
        th = threading.Thread(target=m_bob.changeValue(self.selected), args=[])
        th.start()
    
    def setStatus(self):
        global m_fps
        
        #check fps
        ret = m_bob.checkClient()
        
        if ret == 1 :
            
            if os.path.isfile("/home/boblight-addons/bob_fps"):
                fo = open("/home/boblight-addons/bob_fps", "r")
                reading = str(fo.read(1000))
                m_fps = "%s" %(str(reading))
            else:
                m_fps = _("Boblight Not active");   
        else:
            m_fps = _("Boblight Not active");
            
        th = threading.Thread(target=self.setFps(), args=[])
        th.start()  

    def setFps(self):
        self["config_fps"].setText(m_fps)
        
    def updateStatus(self, element=None):
        
        self.isMain = True
        
        saveList = []
        if self.boblist == BOBLIST_MAIN:
            saveList.extend(self.boblist_main)    
        elif self.boblist == BOBLIST_COLOR:
            saveList.extend(self.boblist_color)
        elif self.boblist == BOBLIST_MOODLAMP:
            saveList.extend(self.boblist_moodlamp)

        print "[Boblight] saveList: %s" %(str(BOBLIST_TITLES[self.boblist]))
        for x in saveList:
	    x[1].save()
        
        saveList = None

        configfile.save()
        
        if self.isFinisched:
            self["config_title"].setText(BOBLIST_TITLES[self.boblist]) 
            self.setBackground()
            self.setStatus()
            self.selectConfigList()            
    
    def setBackground(self):
        self.c = self["Canvas"]
	if config.plugins.Boblight.color.getValue() == "bgr":
	    self.c.fill(0, 0, 250, 300, RGB(config.plugins.Boblight.moodlamp_static_color_b.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_r.getValue()))
	else:
	    self.c.fill(0, 0, 250, 300, RGB(config.plugins.Boblight.moodlamp_static_color_r.getValue(),config.plugins.Boblight.moodlamp_static_color_g.getValue(),config.plugins.Boblight.moodlamp_static_color_b.getValue()))    
        self.c.flush()
        
    #############
    #
    # Mainmenu
    #
    ############# 
    def updateMainConfig(self, element=None):   
        self.boblist_main = [
            getConfigListEntry(_('Give message when new update available:'),config.plugins.Boblight.checkforupdate),
            getConfigListEntry(_('Give message when turn on/off lights:'),config.plugins.Boblight.message_onoff),
            
            getConfigListEntry(_('Enable lights on boot:'),config.plugins.Boblight.autostart),
            #getConfigListEntry(_('Switch on/off lights when TV turns on/off:'), config.plugins.Boblight.hdmicec_enabled),
            getConfigListEntry(_('Let daemon running when light is off:'),config.plugins.Boblight.daemon),      
            getConfigListEntry(_('Light Mode:'),config.plugins.Boblight.mode),
            getConfigListEntry(_('Standby Mode:'),config.plugins.Boblight.standbymode),
            getConfigListEntry(_('Cluster Leds:'),config.plugins.Boblight.cluster),
	    getConfigListEntry(_('Delay: (%s)      ') % str(config.plugins.Boblight.m_delay.getValue()), config.plugins.Boblight.m_delay)

        ]
        
        if config.plugins.Boblight.mode.value is str(2):
            self.boblist_main.append(getConfigListEntry(_('Blackbar detection:'), config.plugins.Boblight.blackbar))        
            self.boblist_main.append(getConfigListEntry(_('Interval'), config.plugins.Boblight.interval))   
            self.boblist_main.append(getConfigListEntry(_('3D Mode:'), config.plugins.Boblight.m_3dmode))

        if self.isFinisched:
	        self.selectConfigList()	    
	    #if config.plugins.Boblight.checkforupdate.value is True and config.plugins.Boblight.arch.value != "":
		#    th = threading.Thread(target=self.checkForUpdate(), args=[])
		#    th.start()  
	    
        if config.plugins.Boblight.message_onoff.value == True:
            config.plugins.Boblight.message_onoff.save()
            configfile.save()
	        
    #############
    #
    # Color tuning
    #
    ############# 
    def updateColorConfig(self, element=None):        
        self.boblist_color = [
        getConfigListEntry(_('Profile:'), config.plugins.Boblight.presets),
        ]
                
        #self.boblist_color.append(getConfigListEntry(_('Pixels:'),      config.plugins.Boblight.pixels))
        self.boblist_color.append(getConfigListEntry(_('Smoothing:'),config.plugins.Boblight.interpolation))
        self.boblist_color.append(getConfigListEntry(_('Led speed/fade: (%s%s)      ') % (str(config.plugins.Boblight.speed.getValue()),str('%')),config.plugins.Boblight.speed))
        self.boblist_color.append(getConfigListEntry(_('Auto speed: (%s%s)      ') % (str(config.plugins.Boblight.autospeed.getValue()),str('%')),config.plugins.Boblight.autospeed))
        self.boblist_color.append(getConfigListEntry(_('Brightness: (%s)      ') % str(config.plugins.Boblight.value.getValue()),config.plugins.Boblight.value))
        self.boblist_color.append(getConfigListEntry(_('Minimal Brightness 0.00-1.00:'),config.plugins.Boblight.valuemin))
        self.boblist_color.append(getConfigListEntry(_('Maximal Brightness 0.00-1.00:'),config.plugins.Boblight.valuemax))
        self.boblist_color.append(getConfigListEntry(_('Saturation 0-20:'),config.plugins.Boblight.saturation))
        self.boblist_color.append(getConfigListEntry(_('Minimal Saturation 0.00-1.00:'),config.plugins.Boblight.saturationmin))
        self.boblist_color.append(getConfigListEntry(_('Maximal Saturation 0.00-1.00:'),config.plugins.Boblight.saturationmax))
        self.boblist_color.append(getConfigListEntry(_('Gamma correction 1-10:'),config.plugins.Boblight.gamma))
        self.boblist_color.append(getConfigListEntry(_('Threshold: (%s%s)      ') % (str(config.plugins.Boblight.threshold.getValue()),str('%')),config.plugins.Boblight.threshold))
	
        #save
        self.saveCustom(config.plugins.Boblight.presets.getValue())
      
        if self.isFinisched:
	    self.selectConfigList()
	
    def getCustom(self,profilenr):
        print("[Boblight] Get settings from profile[%s]..." %(str(profilenr)))
    	try:
            fo = open("/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/profiles/custom_%s.profile" %(str(profilenr)), "r")
            customsettings = fo.read(200)
            print("[Boblight] "+customsettings)
            fo.close()
            
            customsettings = customsettings.split("|")
            config.plugins.Boblight.saturation.setValue(str(customsettings[0]))
            config.plugins.Boblight.value.setValue(int(customsettings[1]))
            config.plugins.Boblight.speed.setValue(int(customsettings[2]))
            config.plugins.Boblight.valuemax.setValue(customsettings[3])
            config.plugins.Boblight.valuemin.setValue(customsettings[4])
            config.plugins.Boblight.saturationmin.setValue(customsettings[5])
            config.plugins.Boblight.saturationmax.setValue(customsettings[6])
            config.plugins.Boblight.gamma.setValue(customsettings[7])
            config.plugins.Boblight.threshold.setValue(int(customsettings[8]))
            config.plugins.Boblight.interpolation.setValue(bool(customsettings[9]))
            config.plugins.Boblight.pixels.setValue(str(customsettings[10]))
            config.plugins.Boblight.autospeed.setValue(int(customsettings[11]))

        except Exception, e:
            print("[Boblight] ERROR: can't get settings: %s" % (e) )
            self.session.open(MessageBox, _("Can't get settings from profile...\n Error:%s" %(e)), MessageBox.TYPE_WARNING, timeout = 10)
            
    def saveCustom(self,profilenr):
        print("[Boblight] Write to profile[%s]..." %(str(profilenr)))
    	
    	try:
            fo = open("/usr/lib/enigma2/python/Plugins/Extensions/Boblight-enigma2/profiles/custom_%s.profile" %(str(profilenr)), "wb")
            fo.write(str(config.plugins.Boblight.saturation.value)+"|")
            fo.write(str(config.plugins.Boblight.value.value)+"|")
            fo.write(str(config.plugins.Boblight.speed.value)+"|")
            fo.write(str(config.plugins.Boblight.valuemax.value)+"|")
            fo.write(str(config.plugins.Boblight.valuemin.value)+"|")
            fo.write(str(config.plugins.Boblight.saturationmin.value)+"|")
            fo.write(str(config.plugins.Boblight.saturationmax.value)+"|")
            fo.write(str(config.plugins.Boblight.gamma.value)+"|")
            fo.write(str(config.plugins.Boblight.threshold.value)+"|")
            fo.write(str(config.plugins.Boblight.interpolation.value)+"|")
            fo.write(str(config.plugins.Boblight.pixels.value)+"|")
            fo.write(str(config.plugins.Boblight.autospeed.value))

            fo.close();
            
        except Exception, e:
            print("[Boblight] ERROR: can't write settings: %s" % (e) )
            self.session.open(MessageBox, _("Can't write settings to profile...\n Error:%s" %(e)), MessageBox.TYPE_WARNING, timeout = 10)
            
	#############
    #
    # Moodlamp
    #
    ############# 
    def updateMoodlampConfig(self, element=None):
        
        self.boblist_moodlamp = [
            getConfigListEntry(_('Moodlamp Mode:'),                             config.plugins.Boblight.moodlamp_mode),            
        ]
        
        if config.plugins.Boblight.moodlamp_mode.value is str(1):

	    self.boblist_moodlamp.append(getConfigListEntry(_('Color sequence:'), config.plugins.Boblight.color))
	    if config.plugins.Boblight.color.getValue() == "rgb":
		self.boblist_moodlamp.append(getConfigListEntry(_('Color RED : %s      ') % str(config.plugins.Boblight.moodlamp_static_color_r.getValue()), config.plugins.Boblight.moodlamp_static_color_r))
		self.boblist_moodlamp.append(getConfigListEntry(_('Color GREEN : %s      ') % str(config.plugins.Boblight.moodlamp_static_color_g.getValue()), config.plugins.Boblight.moodlamp_static_color_g))
		self.boblist_moodlamp.append(getConfigListEntry(_('Color BLUE : %s      ') % str(config.plugins.Boblight.moodlamp_static_color_b.getValue()), config.plugins.Boblight.moodlamp_static_color_b))
	    elif config.plugins.Boblight.color.getValue() == "bgr":
		self.boblist_moodlamp.append(getConfigListEntry(_('Color BLUE : %s      ') % str(config.plugins.Boblight.moodlamp_static_color_r.getValue()), config.plugins.Boblight.moodlamp_static_color_r))
		self.boblist_moodlamp.append(getConfigListEntry(_('Color GREEN : %s      ') % str(config.plugins.Boblight.moodlamp_static_color_g.getValue()), config.plugins.Boblight.moodlamp_static_color_g))
		self.boblist_moodlamp.append(getConfigListEntry(_('Color RED : %s      ') % str(config.plugins.Boblight.moodlamp_static_color_b.getValue()), config.plugins.Boblight.moodlamp_static_color_b))

        if config.plugins.Boblight.moodlamp_mode.value is str(4):
            self.boblist_moodlamp.append(getConfigListEntry(_('Fader brightness : %s      ') % str(config.plugins.Boblight.moodlamp_fader_brightness.getValue()), config.plugins.Boblight.moodlamp_fader_brightness))
        self.selectConfigList()
    
    def setInfoText(self):
        print("[Boblight] Set infoText")
        Option = self["config"].getCurrent()[1]
        text = ""
        if Option == config.plugins.Boblight.presets:
            text = "Profile: \nCreate a profile. it will be saved automatic"
        elif Option == config.plugins.Boblight.interpolation:
            text = "Smoothing: \nThis option will make the image smoother."
        elif Option == config.plugins.Boblight.speed:
            text = "Led speed/fade​​: \nGeneral setting for the led-speed how fast is changing the colour. 40 is a nice setting."
        elif Option == config.plugins.Boblight.threshold:
            text = "Threshold:\nHow high must the brightness should be of an average flat before the LEDs react to it. Simple. A nice value is 30-40 otherwise it will flickering a lot in almost dark scenes."
        elif Option == config.plugins.Boblight.saturation:
            text = "Saturation:\nSimply a strengthening of the average colour planes. The best option is between 1:00 and 1:20. This is because you are going to reinforce colours and this is so unnatural. \nExample:\n many films have a colour grading over it. A well-known example is a blue tint. This affects all the colours on the screen so that even a light Gray sky has some blue tones in it. When you try saturation on 2, it will thus be seen as good this blue tint twice while it appears white on your screen."
        elif Option == config.plugins.Boblight.value:
            text = "Brightness:\nThis is a nice option, especially even more important than the saturation setting. Why? Simply because there are colours like brown, turquoise, purple and eggplant that only exist with the clarity they have. Huh! Well, for example, a dark brown orange and dark turquoise aqua. So if you set the brightness to 2.0 then multiply the brightness of the colour you see with 2.0 (I think) and therefore can not show brown Ambilight. A nice value is 1.0 otherwise it quickly distorts the colours."
        elif Option == config.plugins.Boblight.valuemin: 
            text= "Minimal Brightness:\nIf you set this as example to 0.01, then the LEDs will not completely dark is there is black but soft grey"
        elif Option == config.plugins.Boblight.valuemax: 
            text= "Maximal Brightness:\n Not available yet."
        elif Option == config.plugins.Boblight.gamma: 
            text= "Gamma correction:\n Set this to 2.2 for default, since this is a default value for movies."
        elif Option == config.plugins.Boblight.interval:
            text = "0.01 = 15 -> 40fps | 0.10 = 10fps | 0.20 = 5fps:"
        #elif Option == config.plugins.Boblight.hdmicec_enabled:
        #    text = "This function is in BETA!\n\nTurn on/off lights when you turn on/off your tv.\n This function used the Hdmi-CEC driver on your box.\nBoblight daemon will stay running."
        elif Option == config.plugins.Boblight.cluster:
            text = "This function is in BETA!\n\nCluster [X] Leds as one led.\nDefault each led had is own color, with this option you can bundle/cluster this to 2 -> 10 leds."
        elif Option == config.plugins.Boblight.blackbar:
            text = "Scan every second for blackbars on top/bottom.\nThis function needs 5-10sec to detect the blackbars!"
	elif Option == config.plugins.Boblight.m_delay:
	    text = "Delay for some tv's where the tv signal is slower then lights. With this option you can make the output 1 -> 20 frames later."
        else:
            text = "No information available yet."
            
        self["config_information_text"].setText(text)
        self.setStatus()
       
    def keyNext(self):
	print "keyNext"
	self.selected = self["config"].getCurrent()[1] 
	if self.selected == config.plugins.Boblight.moodlamp_static_color_r:
	    config.plugins.Boblight.moodlamp_static_color_r.setValue(Clamp(config.plugins.Boblight.moodlamp_static_color_r.getValue()+10,0,255))
	elif self.selected == config.plugins.Boblight.moodlamp_static_color_g:
	    config.plugins.Boblight.moodlamp_static_color_g.setValue(Clamp(config.plugins.Boblight.moodlamp_static_color_g.getValue()+10,0,255))
	elif self.selected == config.plugins.Boblight.moodlamp_static_color_b:
	    config.plugins.Boblight.moodlamp_static_color_b.setValue(Clamp(config.plugins.Boblight.moodlamp_static_color_b.getValue()+10,0,255))
	self.changedEntry() #Refresh list
	
    def keyPrev(self):
	print "keyPrev"
	self.selected = self["config"].getCurrent()[1] 
	if self.selected == config.plugins.Boblight.moodlamp_static_color_r:
	    config.plugins.Boblight.moodlamp_static_color_r.setValue(Clamp(config.plugins.Boblight.moodlamp_static_color_r.getValue()-10,0,255))
	elif self.selected == config.plugins.Boblight.moodlamp_static_color_g:
	    config.plugins.Boblight.moodlamp_static_color_g.setValue(Clamp(config.plugins.Boblight.moodlamp_static_color_g.getValue()-10,0,255))
	elif self.selected == config.plugins.Boblight.moodlamp_static_color_b:
	    config.plugins.Boblight.moodlamp_static_color_b.setValue(Clamp(config.plugins.Boblight.moodlamp_static_color_b.getValue()-10,0,255))
	self.changedEntry() #Refresh list
	
    def sendValue(self):
        if not self.isFinisched:
            return
        self.selected = self["config"].getCurrent()[1]

        th = threading.Thread(target=m_bob.changeValue(self.selected), args=[])
        th.start()
	                    
    def getCurrentValue(self):
        return str(self["config"].getCurrent()[1].getText())

    def keyOk(self):
        self.SaveConfig()
        
        self.states_running = False
        self.states_stop = True
        self.close(True, self.session)
                
    def keyYellow(self):
        self.SaveConfig()
    	m_bob.Restart(self.session)
    	self.session.open(MessageBox, _("Restart.."), MessageBox.TYPE_INFO, timeout=3)
    	self.selectConfigList()
 
    def keyInfo(self):
        self.isMain = False
        self.session.open(BoblightAboutScreen)
       
    def keyGreen(self):
        self.SaveConfig()   
        m_bob.Lights_on(self.session)    
        self.selectConfigList()    
        self.setStatus()

    def keyRed(self):        
        m_bob.Lights_off(self.session)
        self.selectConfigList()
        self.setStatus()
        
    def keyBlue(self):
        self.session.openWithCallback(self.resetData, MessageBox, _("Reset data to default values?"))
    
    def keyExit(self):
        self.SaveConfig()
        self.close(False, self.session)
		
    def key1(self):
        self.boblist = BOBLIST_MAIN
        self.selectConfigList()
	    # update running status etc
        self.updateStatus()

    def key2(self):
        self.boblist = BOBLIST_COLOR
        self.selectConfigList()
        # update running status etc
        self.updateStatus()

    def key3(self):
        self.boblist = BOBLIST_MOODLAMP
        self.selectConfigList()
        # update running status etc
        self.updateStatus()

    def key4(self):
        self.session.open(NetworkSettingsScreen)
        # update running status etc
        self.updateStatus()
        self.isMain = False
    
    def key5(self):
        self.session.open(DeviceConfigScreen)
        # update running status etc
        self.updateStatus()
        self.isMain = False
        
    def key6(self):
        self.session.open(TimerSettingsScreen)
        # update running status etc
        self.updateStatus()
        self.isMain = False
    
    def key8(self):        
        self.session.open(AdjustmentScreen)
        # update running status etc
        self.updateStatus()
        self.isMain = False
        	
    def SaveConfirm(self, result):
        if result:
	    self.SaveConfig()
        else:
	    self.CancelConfig()
			    
    def SaveConfig(self):
        saveList = []
        saveList.extend(self.boblist_main)
        saveList.extend(self.boblist_color)
        saveList.extend(self.boblist_moodlamp)

        for x in saveList:
	    x[1].setNotifiers(None)
	    x[1].save()
        
        saveList = None

        configfile.save()

        RC_START_LINK = '/etc/rc3.d/S99boblight'
    
        if config.plugins.Boblight.autostart.value is True:
            self.LinkFile('/etc/init.d/boblight-control', RC_START_LINK)            
        if config.plugins.Boblight.autostart.value is False:
            self.DeleteLink(RC_START_LINK)

    def CancelConfig(self):
        cancelList = []
        cancelList.extend(self.boblist_main)
        cancelList.extend(self.boblist_color)
        cancelList.extend(self.boblist_network)
        cancelList.extend(self.boblist_moodlamp)

        for x in cancelList:
	        x[1].setNotifiers(None)
	        if x[1].isChanged():
		        x[1].cancel()
		        m_bob.sendAll()
        cancelList = None
		       
    def SaveConfirm(self, result):
        if result is None or result is False:
            print "[Boblight] Save not confirmed. exit.."
            for x in self["config"].list:
                x[1].cancel()
        else:
            print "[Boblight] Save confirmed. Configchanges will be saved."
            self.SaveConfig()
            
    def resetData(self, element=None):
        self.isFinisched = False

        #Main
        config.plugins.Boblight.autostart.setValue(False)
        config.plugins.Boblight.mode.setValue(2)
        config.plugins.Boblight.m_3dmode.setValue(1)
        config.plugins.Boblight.network_onoff.setValue(False)
        
        #Moodlamp
        config.plugins.Boblight.moodlamp_static_color_r.setValue(255)
        config.plugins.Boblight.moodlamp_static_color_g.setValue(025)
        config.plugins.Boblight.moodlamp_static_color_b.setValue(002)
        config.plugins.Boblight.moodlamp_static_color_r_int.setValue(255)
        config.plugins.Boblight.moodlamp_static_color_g_int.setValue(025)
        config.plugins.Boblight.moodlamp_static_color_b_int.setValue(002)
        config.plugins.Boblight.network_onoff.setValue(False)
        config.plugins.Boblight.moodlamp_static.setValue(False)
        config.plugins.Boblight.presets.setValue(1)
        
        #Color settings
        config.plugins.Boblight.presets.setValue(0)          
        config.plugins.Boblight.saturation.setValue(str(1.0))
        config.plugins.Boblight.value.setValue(4)
        config.plugins.Boblight.speed.setValue(50)
        config.plugins.Boblight.valuemax.setValue(1.0)
        config.plugins.Boblight.valuemin.setValue(0.1)
        config.plugins.Boblight.saturationmin.setValue(0.0)
        config.plugins.Boblight.saturationmax.setValue(1.0)
        config.plugins.Boblight.gamma.setValue(str(2.2)) 
        config.plugins.Boblight.threshold.setValue(40)
        config.plugins.Boblight.interpolation.setValue(True) 
        
        #hdmicec
        #config.plugins.Boblight.hdmicec_enabled.setValue(False)
        
            
        self.isFinisched = True
        
		# update status
        self.isFinisched = False

        self.updateMainConfig()
        self.isFinisched = True
		
        self.selectConfigList()
		
		#send all values to client        
        th = threading.Thread(target=m_bob.sendAll(), args=[])
        th.start()
		
    def LinkFile(self, src, dst):
        print "[Boblight] Create symlink."
        if (os.access(dst, os.F_OK) or os.symlink(src, dst)):
            pass

    def DeleteLink(self, dst):
        print "[Boblight] Delete symlink."
        if (os.access(dst, os.F_OK) and os.unlink(dst)):
            pass
                 
class BoblightUpdate(Screen, ConfigListScreen):
    skin = """
	    <screen position="100,100" size="500,380" title="Update Boblight" >
		    <widget name="text" position="10,10" size="480,360" font="Regular;22" />
	    </screen>"""

    def __init__(self, session, remoteurl):
        self.skin = BoblightUpdate.skin
        Screen.__init__(self, session)

        self.Console = Console()
        self["text"] = ScrollLabel("Checking for updates....")

        self["actions"] = ActionMap(["BoblightActions"],
        {
	        "ok": self.close,
	        "back": self.close,
	        "cancel": self.close
        }, -1)

        self.url = remoteurl

        self.onFirstExecBegin.append(self.initupdate)
    
    def initupdate(self):
	    cmd = "opkg install -force-overwrite " + str(self.url)    
	    print ("[Boblight] initupdate: " + cmd)
	
	    self["text"].setText("Updating Boblight ...\n\n\nPlease wait...")
	    self.Console.ePopen(cmd, self.startupdate)

    def startupdate(self, result, retval, extra_args):
	if retval == 0:
	    self["text"].setText(result)
	    print ("[Boblight] startupdate result: " + result)
	    
	    message = self.session.openWithCallback(self.restartGUI,MessageBox,_("GUI needs a restart to apply new Boblight-E2 version.\nDo you want to Restart the GUI now ?"), MessageBox.TYPE_YESNO)
	    message.setTitle(_("Restart GUI"))
	else:
	    print ("[Boblight] startupdate: retval =  " + str(retval))
	    message = self.session.openWithCallback(self.retryUpdate,MessageBox,_("Error: something goes wrong while installing new update. Retry ?"), MessageBox.TYPE_YESNO)
	    message.setTitle(_("Retry Update"))
	    
    def restartGUI(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()
    
    def retryUpdate(self, answer):
        if answer is True:
            self.initupdate()
        else:
            self.close()
